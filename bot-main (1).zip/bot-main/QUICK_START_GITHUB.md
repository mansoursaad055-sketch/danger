# 🚀 دليل سريع: تحميل البوت من GitHub إلى WispByte

دليل مختصر لتحميل البوت مباشرة من GitHub بدون رفع ملفات.

---

## ✅ **الطريقة الأسهل: استخدام Git مباشرة**

### 📍 **الخطوة 1: إنشاء حساب في WispByte**

1. اذهب إلى: https://wispbyte.com
2. اضغط **Sign Up**
3. املأ البيانات وفعّل الحساب من الإيميل

---

### 📍 **الخطوة 2: إنشاء بوت جديد**

1. في لوحة التحكم اضغط **Create Bot** أو **New Bot**
2. اختر:
   - **Type**: Discord Bot
   - **Language**: Node.js
   - **Version**: 18.x أو أحدث
3. اضغط **Create**

---

### 📍 **الخطوة 3: تحميل من GitHub**

#### **خيار أ: استخدام Git في Console**

1. في لوحة WispByte اذهب إلى **Console** أو **Terminal**
2. نفذ هذه الأوامر:

```bash
# احذف الملفات الافتراضية (إن وجدت)
rm -rf *

# نزّل المشروع من GitHub
git clone https://github.com/GameOver305/bot.git .

# ثبت الحزم المطلوبة
npm install
```

3. انتظر حتى تكتمل جميع العمليات

#### **خيار ب: ربط GitHub مباشرة (إذا متوفر)**

بعض منصات الاستضافة تدعم الربط المباشر:

1. في WispByte ابحث عن **GitHub Integration** أو **Import from GitHub**
2. ادخل رابط المستودع:
   ```
   https://github.com/GameOver305/bot
   ```
3. اختر Branch: **main**
4. اضغط **Deploy**

---

### 📍 **الخطوة 4: إضافة المتغيرات البيئية** ⭐ مهم!

في **Settings** → **Environment Variables** أضف:

```
DISCORD_TOKEN=ضع_توكن_البوت_هنا
OWNER_ID=ضع_معرفك_هنا
GUILD_ID=ضع_معرف_السيرفر_هنا
NODE_ENV=production
```

**كيف تحصل عليها؟**

#### **DISCORD_TOKEN:**
1. https://discord.com/developers/applications
2. اختر تطبيقك → **Bot** → **Reset Token** → Copy

#### **OWNER_ID:**
1. في Discord: Settings → Advanced → فعّل **Developer Mode**
2. انقر بزر الماوس الأيمن على اسمك → **Copy User ID**

#### **GUILD_ID:**
1. انقر بزر الماوس الأيمن على السيرفر → **Copy Server ID**

---

### 📍 **الخطوة 5: تحديد أمر التشغيل**

في **Settings** → **Start Command**:
```bash
npm start
```

فعّل أيضاً:
- ✅ **Auto Restart**
- ✅ **Restart on Crash**

---

### 📍 **الخطوة 6: تشغيل البوت** 🚀

1. اضغط زر **Start** ▶️
2. راقب **Console/Logs**
3. يجب أن ترى:
```
✅ Bot is ready!
📝 Logged in as: YourBot#1234
```

---

### 📍 **الخطوة 7: دعوة البوت للسيرفر**

1. اذهب إلى: https://discord.com/developers/applications
2. اختر تطبيقك → **OAuth2** → **URL Generator**
3. في **Scopes** اختر:
   - ✅ bot
   - ✅ applications.commands
4. في **Bot Permissions** اختر:
   - ✅ Send Messages
   - ✅ Embed Links
   - ✅ Read Message History
   - ✅ Use Slash Commands
5. انسخ الرابط وافتحه لدعوة البوت

---

### 📍 **الخطوة 8: تجربة البوت**

في سيرفر Discord اكتب:
```
/dang
```

يجب أن تظهر لوحة التحكم! 🎉

---

## 🔄 **تحديث البوت لاحقاً**

عندما تعدّل الكود وترفعه على GitHub:

```bash
# في Console على WispByte:
git pull origin main
npm install
```

ثم أعد تشغيل البوت (Restart)

---

## ❓ **حل المشاكل الشائعة**

### ❌ **خطأ: Command 'git' not found**
بعض الاستضافات لا تدعم Git. استخدم:
1. قم بتنزيل المشروع كـ ZIP من GitHub
2. ارفعه على WispByte
3. فك الضغط في File Manager

### ❌ **خطأ: npm install failed**
جرب:
```bash
rm -rf node_modules package-lock.json
npm install
```

### ❌ **البوت لا يعمل**
تحقق من:
1. السجلات في Console
2. صحة المتغيرات البيئية (DISCORD_TOKEN خاصة)
3. أن npm install اكتمل بنجاح

---

## 📊 **ملخص الأوامر السريعة**

```bash
# تحميل من GitHub
git clone https://github.com/GameOver305/bot.git .

# تثبيت الحزم
npm install

# اختبار محلي (اختياري)
npm start

# تحديث لاحقاً
git pull origin main && npm install
```

---

## 🎯 **الملخص بـ 3 جمل:**

1. **أنشئ بوت في WispByte** → Console → `git clone + npm install`
2. **أضف المتغيرات** → DISCORD_TOKEN, OWNER_ID, GUILD_ID
3. **شغّل البوت** → Start Command: `npm start` ▶️

---

**سهل صح؟** 😊 الآن كل شي على GitHub وما تحتاج ترفع ملفات يدوياً!

**رابط المستودع:**
https://github.com/GameOver305/bot
