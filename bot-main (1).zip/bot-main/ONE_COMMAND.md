# 🚀 One-Command Deploy for Hosting

## للاستضافة - أمر واحد فقط!

### الطريقة 1: التشغيل الكامل (موصى به)
```bash
./deploy.sh
```

### الطريقة 2: التشغيل السريع
```bash
npm install && npm start
```

### الطريقة 3: إصلاح المشاكل
```bash
./fix.sh && npm start
```

---

## ⚡ للاستضافات المختلفة:

### Railway / Render / Heroku:
```bash
# يعمل تلقائياً! فقط تأكد من:
1. إضافة DISCORD_TOKEN في Environment Variables
2. تفعيل جميع Privileged Intents في Discord Portal
```

### VPS (Ubuntu/Debian):
```bash
# الأمر الواحد الكامل:
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash - && \
sudo apt-get install -y nodejs git && \
git clone <repo-url> && \
cd bot && \
./deploy.sh
```

### Docker:
```bash
docker-compose up -d
```

---

## 🔧 إذا واجهت مشاكل:

```bash
# 1. إصلاح سريع
./fix.sh

# 2. إعادة التشغيل
npm start

# 3. إذا استمرت المشاكل
rm -rf node_modules package-lock.json
npm install
npm start
```

---

## ✅ التحقق من النجاح:

بعد التشغيل يجب أن ترى:
```
✅ Bot is ready!
📝 Logged in as: YourBot#1234
🌐 Servers: 1
✅ Reminder system started
```

---

## 📝 ملاحظات مهمة:

1. **التوكن مطلوب**: لازم تضيف `DISCORD_TOKEN` في `.env`
2. **Privileged Intents**: لازم تفعلها في Discord Developer Portal
3. **الأذونات**: البوت يحتاج "Administrator" أو الأذونات الأساسية
4. **الأوامر**: إذا ما تضيف `GUILD_ID` راح تنتظر ساعة للأوامر

---

## 🎉 بعد التشغيل الناجح:

1. ادعو البوت لسيرفرك
2. اكتب `/dang`
3. استمتع بجميع الميزات!

---

**اللغة الافتراضية الآن: الإنجليزية**
**للتبديل للعربية: زر 🇸🇦 في القائمة الرئيسية**

---

## الملفات المهمة:

- `deploy.sh` - التشغيل الكامل الشامل ⭐
- `fix.sh` - إصلاح المشاكل السريع
- `README_V2.md` - الدليل الشامل الكامل
- `QUICK_DEPLOY.md` - دليل النشر المفصّل
- `V2_CHANGES.md` - ملخص التحديثات

---

**Need Help?** Check README_V2.md or TROUBLESHOOTING.md
