#!/bin/bash

#╔════════════════════════════════════════╗
#║   سكربت تشغيل البوت مع التحديث التلقائي   ║
#╚════════════════════════════════════════╝

echo ""
echo "╔════════════════════════════════════════╗"
echo "║     🤖 Discord Alliance Bot Launcher   ║"
echo "╚════════════════════════════════════════╝"
echo ""

# الانتقال لمسار البوت
cd "$(dirname "$0")"

# التحقق من وجود node_modules
if [ ! -d "node_modules" ]; then
    echo "📦 جاري تثبيت المتطلبات لأول مرة..."
    npm install
    echo ""
fi

# التحقق من وجود ملف .env
if [ ! -f ".env" ]; then
    echo "⚠️ ملف .env غير موجود!"
    echo "📝 جاري إنشاء نموذج..."
    echo "DISCORD_TOKEN=your_bot_token_here" > .env
    echo "OWNER_ID=your_discord_id_here" >> .env
    echo "AUTO_UPDATE=true" >> .env
    echo ""
    echo "⚠️ يرجى تعديل ملف .env وإضافة التوكن الخاص بك"
    exit 1
fi

# تشغيل البوت
echo "🚀 جاري تشغيل البوت..."
echo ""

# التحقق من البيئة
if command -v pm2 &> /dev/null; then
    echo "📦 تم اكتشاف PM2 - جاري التشغيل..."
    pm2 start ecosystem.config.js --update-env
else
    # تشغيل عادي
    node src/index.js
fi
