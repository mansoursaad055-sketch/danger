import { ButtonManager } from './buttonManager.js';
import db from '../utils/database.js';
import { t } from '../utils/translations.js';
import { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } from 'discord.js';

export async function handleButtonInteraction(interaction) {
  const userId = interaction.user.id;
  const user = db.getUser(userId);
  const lang = user.language || 'en';
  const customId = interaction.customId;

  try {
    // Language switcher
    if (customId === 'lang_switch') {
      const newLang = lang === 'ar' ? 'en' : 'ar';
      db.setUserLanguage(userId, newLang);
      await interaction.update(ButtonManager.createMainMenu(newLang));
      return;
    }

    // Main menu navigation
    if (customId === 'menu_bookings' || customId === 'menu_ministry_appointments') {
      await interaction.update(ButtonManager.createMinistryAppointmentsMenu(lang));
    } 
    else if (customId === 'menu_alliance') {
      await interaction.update(ButtonManager.createAllianceMenu(lang));
    }
    else if (customId === 'menu_reminders') {
      await interaction.update(ButtonManager.createRemindersMenu(userId, lang));
    }
    else if (customId === 'menu_settings') {
      await interaction.update(ButtonManager.createSettingsMenu(userId, lang));
    }
    else if (customId === 'menu_permissions') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: t(lang, 'permissions.ownerOnly'), ephemeral: true });
        return;
      }
      await interaction.update(ButtonManager.createPermissionsMenu(userId, lang));
    }
    else if (customId === 'menu_help') {
      await interaction.update(ButtonManager.createHelpMenu(lang));
    }
    else if (customId === 'menu_stats') {
      await interaction.update(ButtonManager.createStatsMenu(lang));
    }

    // New Main Menu Items
    else if (customId === 'menu_members') {
      await interaction.update(ButtonManager.createMembersMenu(userId, lang));
    }
    else if (customId === 'menu_logs') {
      await interaction.update(ButtonManager.createLogsMenu(userId, lang));
    }
    else if (customId === 'menu_schedule') {
      await interaction.update(ButtonManager.createScheduleMenu(userId, lang));
    }

    // Ministry Appointments
    else if (customId === 'appointment_building' || customId === 'appointment_research' || customId === 'appointment_training') {
      const type = customId.replace('appointment_', '');
      await showAppointmentModal(interaction, type, lang);
    }
    else if (customId === 'appointment_view_all') {
      await showAllAppointments(interaction, lang);
    }
    else if (customId === 'appointment_delete') {
      // عرض قائمة اختيار نوع الحذف أولاً
      await interaction.update(ButtonManager.createDeleteAppointmentsMenu(interaction.guildId, 'building', lang));
    }

    // ============ معالجات حذف المواعيد المحسنة ============
    else if (customId.startsWith('appointment_delete_menu_')) {
      const type = customId.replace('appointment_delete_menu_', '');
      await interaction.update(ButtonManager.createDeleteAppointmentsMenu(interaction.guildId, type, lang));
    }
    else if (customId.startsWith('delete_all_')) {
      const type = customId.replace('delete_all_', '');
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      await interaction.update(ButtonManager.createConfirmDeleteAllMenu(type, lang));
    }
    else if (customId.startsWith('confirm_delete_all_')) {
      const type = customId.replace('confirm_delete_all_', '');
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      // حذف جميع المواعيد
      db.clearGuildBookings(interaction.guildId, type);
      await interaction.update(ButtonManager.createMinistryAppointmentsMenu(lang));
      await interaction.followUp({ 
        content: lang === 'ar' 
          ? `✅ تم حذف جميع مواعيد ${type === 'building' ? 'البناء' : type === 'research' ? 'البحث' : 'التدريب'} بنجاح!`
          : `✅ All ${type} appointments deleted successfully!`,
        ephemeral: true 
      });
    }
    else if (customId.startsWith('delete_select_')) {
      const type = customId.replace('delete_select_', '');
      await interaction.update(ButtonManager.createSelectDeleteMenu(interaction.guildId, type, lang));
    }

    // ============ معالجات نقل الأزرار مع موافقة/رفض ============
    else if (customId === 'confirm_button_move') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ المالك فقط' : '❌ Owner only', ephemeral: true });
        return;
      }
      const pendingMove = db.getPendingButtonMove(interaction.guildId);
      if (!pendingMove) {
        await interaction.reply({ content: lang === 'ar' ? '❌ لا يوجد تغيير معلق' : '❌ No pending change', ephemeral: true });
        return;
      }
      // تطبيق النقل
      const layout = db.getButtonLayout();
      const { fromRow, fromCol, toRow, toCol } = pendingMove;
      
      // تبديل الأزرار
      const temp = layout.rows[fromRow][fromCol];
      layout.rows[fromRow][fromCol] = layout.rows[toRow][toCol];
      layout.rows[toRow][toCol] = temp;
      
      db.updateButtonLayout(layout);
      db.clearPendingButtonMove(interaction.guildId);
      
      await interaction.update(ButtonManager.createButtonLayoutMenu(userId, lang));
      await interaction.followUp({ 
        content: lang === 'ar' ? '✅ تم تطبيق التغيير بنجاح!' : '✅ Change applied successfully!',
        ephemeral: true 
      });
    }
    else if (customId === 'reject_button_move') {
      db.clearPendingButtonMove(interaction.guildId);
      await interaction.update(ButtonManager.createButtonLayoutMenu(userId, lang));
      await interaction.followUp({ 
        content: lang === 'ar' ? '❌ تم رفض التغيير' : '❌ Change rejected',
        ephemeral: true 
      });
    }

    // ============ معالجات تعديل النصوص ============
    else if (customId === 'owner_texts') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      await interaction.update(ButtonManager.createEditTextsMenu(userId, lang));
    }

    // ============ ربط التحالف تلقائياً ============
    else if (customId === 'guild_alliance_link') {
      await interaction.update(ButtonManager.createGuildAllianceLinkMenu(interaction.guildId, lang));
    }
    else if (customId === 'guild_sync_members') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      await interaction.deferReply({ ephemeral: true });
      
      try {
        // جلب أعضاء السيرفر
        const guild = interaction.guild;
        await guild.members.fetch();
        const members = guild.members.cache.filter(m => !m.user.bot);
        
        const discordMembers = members.map(m => ({
          id: m.id,
          username: m.user.username,
          displayName: m.displayName
        }));
        
        const result = db.syncGuildMembers(interaction.guildId, discordMembers);
        
        await interaction.editReply({
          content: lang === 'ar'
            ? `✅ **تمت المزامنة بنجاح!**\n\n` +
              `➕ **أعضاء جدد:** ${result.added}\n` +
              `🔄 **تم تحديثهم:** ${result.updated}`
            : `✅ **Sync completed!**\n\n` +
              `➕ **New members:** ${result.added}\n` +
              `🔄 **Updated:** ${result.updated}`
        });
      } catch (error) {
        await interaction.editReply({
          content: lang === 'ar' ? '❌ حدث خطأ أثناء المزامنة' : '❌ Error during sync'
        });
      }
    }
    else if (customId === 'guild_toggle_autosync') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      const guildAlliance = db.getGuildAlliance(interaction.guildId);
      guildAlliance.autoSync = !guildAlliance.autoSync;
      db.saveGuildAlliance(interaction.guildId, guildAlliance);
      await interaction.update(ButtonManager.createGuildAllianceLinkMenu(interaction.guildId, lang));
    }
    else if (customId === 'guild_alliance_register') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      // عرض modal لتسجيل التحالف للسيرفر
      const modal = new ModalBuilder()
        .setCustomId('modal_guild_alliance_register')
        .setTitle(lang === 'ar' ? '📝 تسجيل التحالف' : '📝 Register Alliance');

      const nameInput = new TextInputBuilder()
        .setCustomId('alliance_name')
        .setLabel(lang === 'ar' ? 'اسم التحالف' : 'Alliance Name')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

      const tagInput = new TextInputBuilder()
        .setCustomId('alliance_tag')
        .setLabel(lang === 'ar' ? 'تاغ التحالف (مثال: [ABC])' : 'Alliance Tag (e.g., [ABC])')
        .setStyle(TextInputStyle.Short)
        .setRequired(false);

      const descInput = new TextInputBuilder()
        .setCustomId('alliance_desc')
        .setLabel(lang === 'ar' ? 'وصف التحالف (اختياري)' : 'Description (optional)')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(false);

      modal.addComponents(
        new ActionRowBuilder().addComponents(nameInput),
        new ActionRowBuilder().addComponents(tagInput),
        new ActionRowBuilder().addComponents(descInput)
      );

      await interaction.showModal(modal);
    }

    // Reminder Edit
    else if (customId === 'reminder_edit_message') {
      await showEditReminderMessageModal(interaction, lang);
    }
    else if (customId === 'reminder_set_time') {
      await showSetReminderTimeModal(interaction, lang);
    }

    // Layout Controls
    else if (customId === 'layout_select_btn') {
      // Handle via StringSelectMenu below
    }
    else if (customId === 'layout_move_up') {
      const selected = interaction.message.embeds[0]?.description?.match(/✨.*?\n/)?.[0] ? 
        extractSelectedButton(interaction.message.embeds[0].description) : null;
      if (!selected) {
        await interaction.reply({ content: lang === 'ar' ? '❌ اختر زراً أولاً' : '❌ Select a button first', ephemeral: true });
        return;
      }
      await moveButtonDirection(interaction, selected, 'up', userId, lang);
    }
    else if (customId === 'layout_move_down') {
      const selected = extractSelectedButton(interaction.message.embeds[0]?.description);
      if (!selected) {
        await interaction.reply({ content: lang === 'ar' ? '❌ اختر زراً أولاً' : '❌ Select a button first', ephemeral: true });
        return;
      }
      await moveButtonDirection(interaction, selected, 'down', userId, lang);
    }
    else if (customId === 'layout_move_left') {
      const selected = extractSelectedButton(interaction.message.embeds[0]?.description);
      if (!selected) {
        await interaction.reply({ content: lang === 'ar' ? '❌ اختر زراً أولاً' : '❌ Select a button first', ephemeral: true });
        return;
      }
      await moveButtonDirection(interaction, selected, 'left', userId, lang);
    }
    else if (customId === 'layout_move_right') {
      const selected = extractSelectedButton(interaction.message.embeds[0]?.description);
      if (!selected) {
        await interaction.reply({ content: lang === 'ar' ? '❌ اختر زراً أولاً' : '❌ Select a button first', ephemeral: true });
        return;
      }
      await moveButtonDirection(interaction, selected, 'right', userId, lang);
    }
    else if (customId === 'layout_swap') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      await interaction.update(ButtonManager.createButtonSwapMenu(userId, lang));
    }
    else if (customId === 'layout_edit_labels') {
      await showEditLabelsModal(interaction, lang);
    }

    // Close menu
    else if (customId === 'close_menu') {
      await interaction.message.delete().catch(() => {});
    }

    // Settings buttons
    else if (customId === 'settings_buttons') {
      await interaction.update(ButtonManager.createButtonLayoutMenu(userId, lang));
    }
    else if (customId === 'settings_about') {
      await showAboutMenu(interaction, lang);
    }
    else if (customId === 'settings_update') {
      await checkBotUpdate(interaction, lang);
    }

    // Admin permission buttons - use select menu
    else if (customId === 'perm_add_admin') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ المالك فقط' : '❌ Owner only', ephemeral: true });
        return;
      }
      await interaction.update(ButtonManager.createAdminSelectMenu(userId, lang, 'add'));
    }
    else if (customId === 'perm_remove_admin') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ المالك فقط' : '❌ Owner only', ephemeral: true });
        return;
      }
      await interaction.update(ButtonManager.createAdminSelectMenu(userId, lang, 'remove'));
    }

    // Owner default language
    else if (customId === 'owner_default_lang') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ المالك فقط' : '❌ Owner only', ephemeral: true });
        return;
      }
      await interaction.update(ButtonManager.createDefaultLanguageMenu(userId, lang));
    }
    else if (customId === 'set_default_lang_ar') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ المالك فقط' : '❌ Owner only', ephemeral: true });
        return;
      }
      db.applyDefaultLanguageToAll('ar');
      await interaction.update(ButtonManager.createDefaultLanguageMenu(userId, 'ar'));
      await interaction.followUp({ content: '✅ تم تعيين العربية كلغة افتراضية لجميع المستخدمين', ephemeral: true });
    }
    else if (customId === 'set_default_lang_en') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ المالك فقط' : '❌ Owner only', ephemeral: true });
        return;
      }
      db.applyDefaultLanguageToAll('en');
      await interaction.update(ButtonManager.createDefaultLanguageMenu(userId, 'en'));
      await interaction.followUp({ content: '✅ English set as default language for all users', ephemeral: true });
    }

    // Log channel select button
    else if (customId === 'set_log_channel') {
      if (!db.checkPermission(userId, 'admin')) {
        await interaction.reply({ content: t(lang, 'permissions.adminOnly'), ephemeral: true });
        return;
      }
      await interaction.update(ButtonManager.createLogChannelMenu(userId, lang));
    }

    // Back buttons
    else if (customId === 'back_main') {
      await interaction.update(ButtonManager.createMainMenu(lang));
    }
    else if (customId === 'back_permissions') {
      await interaction.update(ButtonManager.createPermissionsMenu(userId, lang));
    }
    else if (customId === 'back_bookings') {
      await interaction.update(ButtonManager.createBookingsMenu(lang));
    }
    else if (customId === 'back_alliance') {
      await interaction.update(ButtonManager.createAllianceMenu(lang));
    }
    else if (customId === 'back_owner_admin') {
      await interaction.update(ButtonManager.createOwnerAdminMenu(userId, lang));
    }

    // Owner Admin Panel
    else if (customId === 'menu_owner_admin') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ هذه القائمة للمالك فقط' : '❌ This menu is owner only', ephemeral: true });
        return;
      }
      await interaction.update(ButtonManager.createOwnerAdminMenu(userId, lang));
    }
    else if (customId === 'owner_guilds') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      await interaction.update(ButtonManager.createGuildsMenu(userId, lang));
    }
    else if (customId === 'owner_buttons') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      await interaction.update(ButtonManager.createButtonLayoutMenu(userId, lang));
    }
    else if (customId === 'owner_permissions') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      await interaction.update(ButtonManager.createPermissionsMenu(userId, lang));
    }

    // Auto Update Bot
    else if (customId === 'owner_auto_update') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      await interaction.deferReply({ ephemeral: true });
      
      try {
        const https = await import('https');
        const fs = await import('fs');
        const path = await import('path');
        
        const REPO_OWNER = 'GameOver305';
        const REPO_NAME = 'bot';
        const BRANCH = 'main';
        
        // Files to update
        const filesToUpdate = [
          'src/index.js',
          'src/handlers/buttonManager.js',
          'src/handlers/interactionHandler.js',
          'src/handlers/modalHandler.js',
          'src/utils/database.js',
          'src/utils/translations.js',
          'src/commands/dang.js',
          'src/commands/stats.js',
          'src/commands/addadmin.js',
          'src/commands/removeadmin.js',
          'src/services/reminderService.js',
          'package.json'
        ];
        
        await interaction.editReply({ 
          content: lang === 'ar' ? '🔄 جاري تحميل التحديثات من GitHub...' : '🔄 Downloading updates from GitHub...' 
        });
        
        // Function to download file from GitHub
        const downloadFile = (filePath) => {
          return new Promise((resolve, reject) => {
            const url = `https://raw.githubusercontent.com/${REPO_OWNER}/${REPO_NAME}/${BRANCH}/${filePath}`;
            https.get(url, (response) => {
              if (response.statusCode === 404) {
                resolve(null); // File doesn't exist, skip
                return;
              }
              if (response.statusCode !== 200) {
                reject(new Error(`HTTP ${response.statusCode}`));
                return;
              }
              let data = '';
              response.on('data', chunk => data += chunk);
              response.on('end', () => resolve(data));
              response.on('error', reject);
            }).on('error', reject);
          });
        };
        
        let updatedCount = 0;
        let errorCount = 0;
        
        for (const filePath of filesToUpdate) {
          try {
            const content = await downloadFile(filePath);
            if (content) {
              const fullPath = path.join(process.cwd(), filePath);
              
              // Ensure directory exists
              const dir = path.dirname(fullPath);
              if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
              }
              
              // Read current file to check if different
              let currentContent = '';
              try {
                currentContent = fs.readFileSync(fullPath, 'utf8');
              } catch (e) {}
              
              if (content !== currentContent) {
                fs.writeFileSync(fullPath, content, 'utf8');
                updatedCount++;
              }
            }
          } catch (err) {
            errorCount++;
            console.error(`Error updating ${filePath}:`, err.message);
          }
        }
        
        if (updatedCount === 0) {
          await interaction.editReply({ 
            content: lang === 'ar' 
              ? '✅ البوت محدث بالفعل! لا توجد تحديثات جديدة.' 
              : '✅ Bot is already up to date! No new updates.' 
          });
          return;
        }
        
        // Check if package.json was updated to run npm install
        const { exec } = await import('child_process');
        const { promisify } = await import('util');
        const execAsync = promisify(exec);
        
        await interaction.editReply({ 
          content: lang === 'ar' ? '📦 جاري تثبيت المتطلبات...' : '📦 Installing dependencies...' 
        });
        
        try {
          await execAsync('npm install', { cwd: process.cwd(), timeout: 60000 });
        } catch (npmErr) {
          console.error('npm install error:', npmErr.message);
        }
        
        await interaction.editReply({ 
          content: lang === 'ar' 
            ? `✅ تم التحديث بنجاح!\n\n📁 **ملفات محدثة:** ${updatedCount}\n${errorCount > 0 ? `⚠️ أخطاء: ${errorCount}\n` : ''}\n🔄 **جاري إعادة تشغيل البوت...**`
            : `✅ Update successful!\n\n📁 **Files updated:** ${updatedCount}\n${errorCount > 0 ? `⚠️ Errors: ${errorCount}\n` : ''}\n🔄 **Restarting bot...**`
        });
        
        // Restart bot after 2 seconds
        setTimeout(() => {
          process.exit(0); // PM2 or hosting will restart the bot
        }, 2000);
        
      } catch (error) {
        console.error('Update error:', error);
        await interaction.editReply({ 
          content: lang === 'ar' 
            ? `❌ خطأ في التحديث:\n\`\`\`\n${error.message}\n\`\`\``
            : `❌ Update error:\n\`\`\`\n${error.message}\n\`\`\``
        });
      }
    }

    // Owner Text Control
    else if (customId === 'owner_texts') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      await interaction.update(ButtonManager.createCustomTextsMenu(userId, lang));
    }

    // Owner Security
    else if (customId === 'owner_security') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      await interaction.update(ButtonManager.createSecurityMenu(userId, lang));
    }

    // Owner Cleanup
    else if (customId === 'owner_cleanup') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      
      const result = db.cleanupExpiredBookings();
      await interaction.reply({
        content: lang === 'ar' 
          ? `🧹 **تم التنظيف بنجاح!**\n\n📊 **الحجوزات المحذوفة:** ${result.deletedCount}\n⏰ **وقت التنظيف:** ${new Date().toLocaleString('ar-SA')}`
          : `🧹 **Cleanup successful!**\n\n📊 **Deleted bookings:** ${result.deletedCount}\n⏰ **Cleanup time:** ${new Date().toLocaleString()}`,
        ephemeral: true
      });
    }

    // Text Edit Handlers
    else if (customId === 'text_edit_title') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      await showTextEditModal(interaction, 'mainTitle', lang);
    }
    else if (customId === 'text_edit_welcome') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      await showTextEditModal(interaction, 'welcomeMessage', lang);
    }
    else if (customId === 'text_edit_buttons') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      await showTextEditModal(interaction, 'buttonLabels', lang);
    }
    else if (customId === 'text_reset_all') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      db.setCustomText('mainTitle', null);
      db.setCustomText('welcomeMessage', null);
      db.setCustomText('buttonLabels', null);
      await interaction.reply({
        content: lang === 'ar' ? '✅ تم إعادة تعيين جميع النصوص للافتراضي!' : '✅ All texts reset to defaults!',
        ephemeral: true
      });
    }

    // Security Handlers
    else if (customId === 'security_view_logs') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      const logs = db.getActivityLogs ? db.getActivityLogs() : [];
      const recentLogs = logs.slice(-10);
      let logText = recentLogs.map(log => `• ${log.timestamp}: ${log.action} - ${log.user}`).join('\n') || (lang === 'ar' ? 'لا توجد سجلات' : 'No logs');
      await interaction.reply({
        content: lang === 'ar' 
          ? `📋 **آخر 10 سجلات نشاط:**\n\n${logText}`
          : `📋 **Last 10 activity logs:**\n\n${logText}`,
        ephemeral: true
      });
    }
    else if (customId === 'security_backup') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      const fs = await import('fs');
      const path = await import('path');
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupDir = path.join(process.cwd(), 'data', 'backups');
      
      if (!fs.existsSync(backupDir)) {
        fs.mkdirSync(backupDir, { recursive: true });
      }
      
      const dataFiles = ['users.json', 'permissions.json', 'alliance.json', 'bookings.json', 'guilds.json', 'ministries.json'];
      let backedUp = 0;
      
      for (const file of dataFiles) {
        const srcPath = path.join(process.cwd(), 'data', file);
        const destPath = path.join(backupDir, `${timestamp}_${file}`);
        if (fs.existsSync(srcPath)) {
          fs.copyFileSync(srcPath, destPath);
          backedUp++;
        }
      }
      
      await interaction.reply({
        content: lang === 'ar' 
          ? `✅ **تم النسخ الاحتياطي بنجاح!**\n\n📁 **ملفات:** ${backedUp}\n📅 **الوقت:** ${timestamp}`
          : `✅ **Backup successful!**\n\n📁 **Files:** ${backedUp}\n📅 **Time:** ${timestamp}`,
        ephemeral: true
      });
    }
    else if (customId === 'security_ban_user') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      await showBanUserModal(interaction, lang);
    }
    else if (customId === 'security_unban_user') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      const bannedUsers = db.getBannedUsers ? db.getBannedUsers() : [];
      if (bannedUsers.length === 0) {
        await interaction.reply({
          content: lang === 'ar' ? '✅ لا يوجد مستخدمين محظورين' : '✅ No banned users',
          ephemeral: true
        });
        return;
      }
      await showUnbanUserModal(interaction, lang);
    }

    // Security Restore
    else if (customId === 'security_restore') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      const fs = await import('fs');
      const path = await import('path');
      const backupDir = path.join(process.cwd(), 'data', 'backups');
      
      if (!fs.existsSync(backupDir)) {
        await interaction.reply({
          content: lang === 'ar' ? '❌ لا توجد نسخ احتياطية' : '❌ No backups found',
          ephemeral: true
        });
        return;
      }
      
      const files = fs.readdirSync(backupDir);
      if (files.length === 0) {
        await interaction.reply({
          content: lang === 'ar' ? '❌ لا توجد نسخ احتياطية' : '❌ No backups found',
          ephemeral: true
        });
        return;
      }
      
      // Get latest backup for each file type
      const latestBackups = {};
      for (const file of files) {
        const parts = file.split('_');
        if (parts.length >= 2) {
          const fileType = parts.slice(1).join('_'); // e.g., users.json
          if (!latestBackups[fileType] || file > latestBackups[fileType]) {
            latestBackups[fileType] = file;
          }
        }
      }
      
      let restored = 0;
      for (const [fileType, backupFile] of Object.entries(latestBackups)) {
        const srcPath = path.join(backupDir, backupFile);
        const destPath = path.join(process.cwd(), 'data', fileType);
        if (fs.existsSync(srcPath)) {
          fs.copyFileSync(srcPath, destPath);
          restored++;
        }
      }
      
      db.clearCache(); // Clear cache after restore
      
      await interaction.reply({
        content: lang === 'ar' 
          ? `✅ **تم استعادة النسخة الاحتياطية!**\n\n📁 **ملفات مستعادة:** ${restored}`
          : `✅ **Backup restored!**\n\n📁 **Files restored:** ${restored}`,
        ephemeral: true
      });
    }

    // Advanced Member Management
    else if (customId === 'member_add_advanced') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      await showAdvancedMemberModal(interaction, lang, 'add');
    }
    else if (customId === 'member_edit_game') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      await showAdvancedMemberModal(interaction, lang, 'edit');
    }
    else if (customId === 'member_set_leader') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      await showSetLeaderModal(interaction, lang);
    }
    else if (customId === 'member_view_profile') {
      await showMemberProfileModal(interaction, lang);
    }
    else if (customId === 'member_export') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      const alliance = db.getAlliance();
      const members = alliance.members || [];
      
      if (members.length === 0) {
        await interaction.reply({
          content: lang === 'ar' ? '❌ لا يوجد أعضاء للتصدير' : '❌ No members to export',
          ephemeral: true
        });
        return;
      }
      
      let exportText = lang === 'ar' ? '📋 **قائمة الأعضاء:**\n\n' : '📋 **Members List:**\n\n';
      members.forEach((m, i) => {
        exportText += `${i+1}. ${m.gameName || m.name || 'Unknown'} | ${m.gameId || '-'} | ${m.rank || 'R1'} | Power: ${m.power ? (m.power/1000000).toFixed(1)+'M' : '-'}\n`;
      });
      
      await interaction.reply({
        content: exportText,
        ephemeral: true
      });
    }
    else if (customId.startsWith('member_edit_')) {
      const memberId = customId.replace('member_edit_', '');
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      await showEditMemberModal(interaction, memberId, lang);
    }

    // Guild Management
    else if (customId === 'guild_add') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      await showAddGuildModal(interaction, lang);
    }
    else if (customId === 'guild_remove') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      await showRemoveGuildModal(interaction, lang);
    }
    else if (customId === 'guild_info') {
      const guilds = db.getGuilds();
      let info = lang === 'ar' 
        ? '**📋 معلومات نظام السيرفرات:**\n\n'
        : '**📋 Server System Information:**\n\n';
      info += lang === 'ar'
        ? '• **GUILD_ID** في ملف .env يُستخدم فقط للتسجيل السريع للأوامر في السيرفر المحدد.\n'
        + '• إذا تم تركه فارغاً، يتم تسجيل الأوامر عالمياً (يستغرق حتى ساعة).\n'
        + '• البوت يعمل في جميع السيرفرات المضاف إليها تلقائياً.\n'
        + '• نظام إدارة السيرفرات هنا للتتبع فقط، ليس إلزامياً لعمل البوت.\n\n'
        + `**عدد السيرفرات المسجلة:** ${guilds.registered?.length || 0}`
        : '• **GUILD_ID** in .env is only used for fast command registration in specified server.\n'
        + '• If left empty, commands are registered globally (takes up to 1 hour).\n'
        + '• Bot works in all servers it\'s added to automatically.\n'
        + '• Server management system here is for tracking only, not required for bot operation.\n\n'
        + `**Registered Servers:** ${guilds.registered?.length || 0}`;
      await interaction.reply({ content: info, ephemeral: true });
    }

    // Button Layout
    else if (customId === 'layout_reset') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
        return;
      }
      db.resetButtonLayout();
      await interaction.update(ButtonManager.createButtonLayoutMenu(userId, lang));
      await interaction.followUp({ 
        content: lang === 'ar' ? '✅ تم إعادة تعيين ترتيب الأزرار إلى الوضع الافتراضي' : '✅ Button layout reset to default', 
        ephemeral: true 
      });
    }
    else if (customId === 'layout_preview') {
      await interaction.reply({ 
        ...ButtonManager.createMainMenu(lang), 
        ephemeral: true 
      });
    }

    // Alliance Register Button
    else if (customId === 'alliance_register') {
      const isR5OrAdmin = (db.getAlliance().leader === userId) || db.isAdmin(userId);
      if (!isR5OrAdmin) {
        await interaction.reply({ content: t(lang, 'alliance.noPermission'), ephemeral: true });
        return;
      }
      await showAllianceRegisterModal(interaction, lang);
    }

    // Booking type selection
    else if (customId.startsWith('booking_') && !customId.includes('add') && !customId.includes('view')) {
      const type = customId.split('_')[1];
      await interaction.update(ButtonManager.createBookingTypeMenu(type, lang));
    }

    // Add booking
    else if (customId.startsWith('booking_add_')) {
      const type = customId.replace('booking_add_', '');
      await showBookingModal(interaction, type, lang);
    }

    // View bookings
    else if (customId.startsWith('booking_view_')) {
      const type = customId.replace('booking_view_', '');
      await showBookingsList(interaction, type, lang);
    }

    // Delete booking
    else if (customId.startsWith('booking_delete_')) {
      const type = customId.replace('booking_delete_', '');
      await showDeleteBookingMenu(interaction, type, lang, userId);
    }

    // Confirm delete booking
    else if (customId.startsWith('confirm_delete_')) {
      const [_, __, type, bookingId] = customId.split('_');
      const booking = db.getBookings(type).find(b => b.id === bookingId);
      
      if (!booking) {
        await interaction.reply({ content: lang === 'ar' ? '❌ الحجز غير موجود' : '❌ Booking not found', ephemeral: true });
        return;
      }

      // Check if user owns the booking or is admin
      if (booking.userId !== userId && !db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية لحذف هذا الحجز' : '❌ No permission to delete this booking', ephemeral: true });
        return;
      }

      db.removeBooking(type, bookingId);
      await interaction.update(ButtonManager.createBookingTypeMenu(type, lang));
      await interaction.followUp({ content: t(lang, 'bookings.removed'), ephemeral: true });
    }

    // Cancel delete
    else if (customId.startsWith('cancel_delete_')) {
      const type = customId.split('_')[2];
      await interaction.update(ButtonManager.createBookingTypeMenu(type, lang));
    }

    // Settings
    else if (customId === 'settings_lang_ar' || customId === 'settings_lang_en') {
      const newLang = customId.split('_')[2];
      db.setUser(userId, { language: newLang });
      await interaction.update(ButtonManager.createSettingsMenu(userId, newLang));
      await interaction.followUp({ 
        content: t(newLang, 'settings.languageChanged', { lang: newLang === 'ar' ? 'العربية' : 'English' }), 
        ephemeral: true 
      });
    }
    else if (customId === 'settings_notifications') {
      const currentStatus = user.notifications !== false;
      db.setUser(userId, { notifications: !currentStatus });
      const status = !currentStatus ? t(lang, 'settings.enabled') : t(lang, 'settings.disabled');
      await interaction.update(ButtonManager.createSettingsMenu(userId, lang));
      await interaction.followUp({ 
        content: t(lang, 'settings.notificationsToggled', { status }), 
        ephemeral: true 
      });
    }

    // Alliance members
    else if (customId === 'alliance_members') {
      await showAllianceMembers(interaction, lang);
    }
    else if (customId === 'alliance_info') {
      await showAllianceDetailedInfo(interaction, lang);
    }
    else if (customId === 'alliance_ranks') {
      await showAllianceRanks(interaction, lang);
    }
    else if (customId === 'alliance_commands') {
      await showAllianceCommands(interaction, lang);
    }
    else if (customId === 'alliance_manage_menu') {
      // Check permissions
      if (!db.hasAlliancePermission(userId) && !db.isAdmin(userId)) {
        await interaction.reply({ content: t(lang, 'alliance.noPermission'), ephemeral: true });
        return;
      }
      await interaction.update(ButtonManager.createAllianceManageMenu(userId, lang));
    }

    // Alliance Management Actions
    else if (customId === 'alliance_add_member') {
      if (!db.hasAlliancePermission(userId) && !db.isAdmin(userId)) {
        await interaction.reply({ content: t(lang, 'alliance.noPermission'), ephemeral: true });
        return;
      }
      await showAddMemberModal(interaction, lang);
    }
    else if (customId === 'alliance_remove_member') {
      if (!db.hasAlliancePermission(userId) && !db.isAdmin(userId)) {
        await interaction.reply({ content: t(lang, 'alliance.noPermission'), ephemeral: true });
        return;
      }
      await showRemoveMemberModal(interaction, lang);
    }
    else if (customId === 'alliance_change_rank') {
      if (!db.hasAlliancePermission(userId) && !db.isAdmin(userId)) {
        await interaction.reply({ content: t(lang, 'alliance.noPermission'), ephemeral: true });
        return;
      }
      await showChangeRankModal(interaction, lang);
    }
    else if (customId === 'alliance_set_info') {
      const isR5OrAdmin = (db.getAlliance().leader === userId) || db.isAdmin(userId);
      if (!isR5OrAdmin) {
        await interaction.reply({ content: t(lang, 'alliance.r5Only'), ephemeral: true });
        return;
      }
      await showSetAllianceInfoModal(interaction, lang);
    }
    else if (customId === 'alliance_set_leader') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: t(lang, 'permissions.ownerOnly'), ephemeral: true });
        return;
      }
      await showSetLeaderModal(interaction, lang);
    }

    // Reminders
    else if (customId === 'reminder_add') {
      await showAddReminderModal(interaction, lang);
    }
    else if (customId === 'reminder_view') {
      await showRemindersList(interaction, userId, lang);
    }
    else if (customId === 'reminder_delete') {
      await showDeleteReminderMenu(interaction, userId, lang);
    }
    else if (customId.startsWith('reminder_delete_')) {
      const reminderId = customId.replace('reminder_delete_', '');
      db.removeReminder(userId, reminderId);
      await interaction.update(ButtonManager.createRemindersMenu(userId, lang));
      await interaction.followUp({ content: lang === 'ar' ? '✅ تم حذف التذكير' : '✅ Reminder deleted', ephemeral: true });
    }

    // Admin Management
    else if (customId === 'perm_manage_admins') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: t(lang, 'permissions.ownerOnly'), ephemeral: true });
        return;
      }
      await interaction.update(ButtonManager.createAdminMenu(userId, lang));
    }
    else if (customId === 'admin_add') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: t(lang, 'permissions.ownerOnly'), ephemeral: true });
        return;
      }
      await showAddAdminModal(interaction, lang);
    }
    else if (customId === 'admin_remove') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: t(lang, 'permissions.ownerOnly'), ephemeral: true });
        return;
      }
      await showRemoveAdminModal(interaction, lang);
    }

    // Advanced Alliance Info
    else if (customId === 'view_members_detailed') {
      await showDetailedMembersList(interaction, lang);
    }
    else if (customId === 'view_alliance_activity') {
      await showAllianceActivity(interaction, lang);
    }
    else if (customId === 'export_alliance_data') {
      await exportAllianceData(interaction, lang);
    }

    // Alliance Logs
    else if (customId === 'set_log_channel') {
      if (!db.checkPermission(userId, 'admin')) {
        await interaction.reply({ content: t(lang, 'permissions.adminOnly'), ephemeral: true });
        return;
      }
      await showSetLogChannelModal(interaction, lang);
    }
    else if (customId === 'view_log_channel') {
      await showCurrentLogChannel(interaction, lang);
    }
    else if (customId === 'remove_log_channel') {
      if (!db.checkPermission(userId, 'admin')) {
        await interaction.reply({ content: t(lang, 'permissions.adminOnly'), ephemeral: true });
        return;
      }
      await removeLogChannel(interaction, lang);
    }
    else if (customId === 'view_recent_logs') {
      await showRecentLogs(interaction, lang);
    }

    // Ministries
    else if (customId === 'add_ministry') {
      if (!db.checkPermission(userId, 'admin')) {
        await interaction.reply({ content: t(lang, 'permissions.adminOnly'), ephemeral: true });
        return;
      }
      await showAddMinistryModal(interaction, lang);
    }
    else if (customId === 'view_ministries') {
      await showMinistriesList(interaction, lang);
    }
    else if (customId === 'edit_ministry') {
      if (!db.checkPermission(userId, 'admin')) {
        await interaction.reply({ content: t(lang, 'permissions.adminOnly'), ephemeral: true });
        return;
      }
      await showEditMinistryMenu(interaction, lang);
    }
    else if (customId === 'delete_ministry') {
      if (!db.checkPermission(userId, 'admin')) {
        await interaction.reply({ content: t(lang, 'permissions.adminOnly'), ephemeral: true });
        return;
      }
      await showDeleteMinistryMenu(interaction, lang);
    }
    else if (customId === 'schedule_activity') {
      if (!db.checkPermission(userId, 'admin')) {
        await interaction.reply({ content: t(lang, 'permissions.adminOnly'), ephemeral: true });
        return;
      }
      await showScheduleActivityModal(interaction, lang);
    }
    else if (customId === 'assign_minister') {
      if (!db.checkPermission(userId, 'admin')) {
        await interaction.reply({ content: t(lang, 'permissions.adminOnly'), ephemeral: true });
        return;
      }
      await showAssignMinisterMenu(interaction, lang);
    }

    // Advanced Schedules
    else if (customId === 'create_scheduled_alert') {
      if (!db.checkPermission(userId, 'admin')) {
        await interaction.reply({ content: t(lang, 'permissions.adminOnly'), ephemeral: true });
        return;
      }
      await showCreateScheduledAlertModal(interaction, lang);
    }
    else if (customId === 'view_schedules') {
      await showSchedulesList(interaction, lang);
    }
    else if (customId === 'edit_schedule') {
      if (!db.checkPermission(userId, 'admin')) {
        await interaction.reply({ content: t(lang, 'permissions.adminOnly'), ephemeral: true });
        return;
      }
      await showEditScheduleMenu(interaction, lang);
    }
    else if (customId === 'delete_schedule') {
      if (!db.checkPermission(userId, 'admin')) {
        await interaction.reply({ content: t(lang, 'permissions.adminOnly'), ephemeral: true });
        return;
      }
      await showDeleteScheduleMenu(interaction, lang);
    }
    else if (customId === 'schedule_activity_advanced') {
      if (!db.checkPermission(userId, 'admin')) {
        await interaction.reply({ content: t(lang, 'permissions.adminOnly'), ephemeral: true });
        return;
      }
      await showAdvancedScheduleModal(interaction, lang);
    }
    else if (customId === 'toggle_auto_repeat') {
      if (!db.checkPermission(userId, 'admin')) {
        await interaction.reply({ content: t(lang, 'permissions.adminOnly'), ephemeral: true });
        return;
      }
      await toggleAutoRepeat(interaction, lang);
    }

    // === Members Management ===
    else if (customId === 'member_add') {
      if (!db.hasAlliancePermission(userId) && !db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية R4/R5 أو أدمن فقط' : '❌ R4/R5 or Admin only', ephemeral: true });
        return;
      }
      await showNewAddMemberModal(interaction, lang);
    }
    else if (customId === 'member_remove') {
      if (!db.hasAlliancePermission(userId) && !db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية R4/R5 أو أدمن فقط' : '❌ R4/R5 or Admin only', ephemeral: true });
        return;
      }
      await showNewRemoveMemberModal(interaction, lang);
    }
    else if (customId === 'member_change_rank') {
      if (!db.hasAlliancePermission(userId) && !db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية R4/R5 أو أدمن فقط' : '❌ R4/R5 or Admin only', ephemeral: true });
        return;
      }
      await showNewChangeRankModal(interaction, lang);
    }
    else if (customId === 'member_list_all') {
      await showAllMembersList(interaction, lang);
    }
    else if (customId === 'member_search') {
      await showMemberSearchModal(interaction, lang);
    }

    // === Ministries Management ===
    else if (customId === 'ministry_add') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      await showAddMinistryModal(interaction, lang);
    }
    else if (customId === 'ministry_view') {
      await showMinistriesList(interaction, lang);
    }
    else if (customId === 'ministry_assign') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      await showAssignMinisterModal(interaction, lang);
    }
    else if (customId === 'ministry_schedule') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      await showScheduleActivityModal(interaction, lang);
    }
    else if (customId === 'ministry_delete') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      await showDeleteMinistryModal(interaction, lang);
    }

    // === Logs Management ===
    else if (customId === 'logs_set_channel') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      await showSetLogChannelModal(interaction, lang);
    }
    else if (customId === 'logs_view_all') {
      await showRecentLogs(interaction, lang);
    }
    else if (customId === 'logs_clear_channel') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      await removeLogChannel(interaction, lang);
    }

    // === Schedule Management ===
    else if (customId === 'schedule_create') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      await showAdvancedScheduleModal(interaction, lang);
    }
    else if (customId === 'schedule_view_all') {
      await showSchedulesList(interaction, lang);
    }
    else if (customId === 'schedule_alert') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      await showCreateScheduledAlertModal(interaction, lang);
    }
    else if (customId === 'schedule_delete') {
      if (!db.isAdmin(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      await showDeleteScheduleMenu(interaction, lang);
    }

  } catch (error) {
    console.error('Error handling button interaction:', error);
    try {
      await interaction.reply({ 
        content: t(lang, 'common.error'), 
        ephemeral: true 
      });
    } catch (e) {
      console.error('Failed to send error message:', e);
    }
  }
}

async function showBookingModal(interaction, type, lang) {
  const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, StringSelectMenuBuilder } = await import('discord.js');
  const modal = new ModalBuilder()
    .setCustomId(`booking_modal_${type}`)
    .setTitle(t(lang, `bookings.${type}`));

  // Alliance Name
  const allianceInput = new TextInputBuilder()
    .setCustomId('alliance_name')
    .setLabel(lang === 'ar' ? 'اسم التحالف' : 'Alliance Name')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(lang === 'ar' ? 'أدخل اسم التحالف' : 'Enter alliance name')
    .setRequired(true);

  // In-game Name
  const memberNameInput = new TextInputBuilder()
    .setCustomId('member_name')
    .setLabel(lang === 'ar' ? 'اسم اللاعب في اللعبة' : 'In-game Name')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(interaction.user.username)
    .setRequired(true);

  // Game ID
  const gameIdInput = new TextInputBuilder()
    .setCustomId('game_id')
    .setLabel(lang === 'ar' ? 'معرف اللعبة (Game ID)' : 'Game ID')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('123456789')
    .setRequired(true);

  // Speedup Amount (contextual)
  let speedupLabel = '';
  if (type === 'building') speedupLabel = lang === 'ar' ? 'كمية تسريع البناء' : 'Building Speedup Amount';
  else if (type === 'training') speedupLabel = lang === 'ar' ? 'كمية تسريع التدريب' : 'Training Speedup Amount';
  else if (type === 'research') speedupLabel = lang === 'ar' ? 'كمية تسريع البحث' : 'Research Speedup Amount';
  const speedupInput = new TextInputBuilder()
    .setCustomId('speedup_amount')
    .setLabel(speedupLabel)
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('0')
    .setRequired(false);

  // Time (dropdown)
  const timeSlots = Array.from({ length: 48 }, (_, i) => {
    const hour = String(Math.floor(i / 2)).padStart(2, '0');
    const min = i % 2 === 0 ? '00' : '30';
    return `${hour}:${min}`;
  });
  const timeMenu = new StringSelectMenuBuilder()
    .setCustomId('booking_time')
    .setPlaceholder(lang === 'ar' ? 'اختر الوقت' : 'Select time')
    .addOptions(timeSlots.map(slot => ({
      label: slot,
      value: slot
    })));

  // Preferred Time (dropdown, multi-select)
  const preferredMenu = new StringSelectMenuBuilder()
    .setCustomId('preferred_time')
    .setPlaceholder(lang === 'ar' ? 'اختر الوقت المفضل (اختياري)' : 'Select preferred time (optional)')
    .setMinValues(0)
    .setMaxValues(3)
    .addOptions(timeSlots.map(slot => ({
      label: slot,
      value: slot
    })));

  // Notes (optional)
  const notesInput = new TextInputBuilder()
    .setCustomId('notes')
    .setLabel(lang === 'ar' ? 'ملاحظات (اختياري)' : 'Notes (optional)')
    .setStyle(TextInputStyle.Short)
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder().addComponents(allianceInput),
    new ActionRowBuilder().addComponents(memberNameInput),
    new ActionRowBuilder().addComponents(gameIdInput),
    new ActionRowBuilder().addComponents(speedupInput),
    new ActionRowBuilder().addComponents(timeMenu),
    new ActionRowBuilder().addComponents(preferredMenu),
    new ActionRowBuilder().addComponents(notesInput)
  );

  await interaction.showModal(modal);
}

async function showBookingsList(interaction, type, lang) {
  const bookings = db.getBookings(type);
  if (bookings.length === 0) {
    await interaction.reply({
      content: t(lang, 'bookings.empty'),
      ephemeral: true
    });
    return;
  }

  let message = `**📋 ${t(lang, `bookings.${type}`)}**\n\n`;
  bookings.forEach((booking, index) => {
    message += `**${index + 1}.**\n`;
    message += `${lang === 'ar' ? '👤 اللاعب' : '👤 Player'}: ${booking.memberName || booking.userName || 'N/A'}\n`;
    message += `${lang === 'ar' ? '🆔 معرف اللعبة' : '🆔 Game ID'}: ${booking.gameId || 'N/A'}\n`;
    message += `${lang === 'ar' ? '🤝 التحالف' : '🤝 Alliance'}: ${booking.allianceName || (lang === 'ar' ? 'غير محدد' : 'Not specified')}\n`;
    message += `${lang === 'ar' ? '⏰ الوقت' : '⏰ Time'}: ${booking.bookingTime || (lang === 'ar' ? 'غير محدد' : 'Not specified')}\n`;
    if (booking.preferredTime && booking.preferredTime.length > 0) {
      message += `${lang === 'ar' ? '⭐ الوقت المفضل' : '⭐ Preferred Time'}: ${Array.isArray(booking.preferredTime) ? booking.preferredTime.join(', ') : booking.preferredTime}\n`;
    }
    if (booking.speedupAmount) {
      message += `${lang === 'ar' ? '⚡ كمية التسريع' : '⚡ Speedup'}: ${booking.speedupAmount}\n`;
    }
    if (booking.notes) {
      message += `${lang === 'ar' ? '📝 ملاحظات' : '📝 Notes'}: ${booking.notes}\n`;
    }
    message += '\n';
  });

  await interaction.reply({
    content: message,
    ephemeral: true
  });
}

async function showAllianceMembers(interaction, lang) {
  const alliance = db.getAlliance();
  
  if (alliance.members.length === 0) {
    await interaction.reply({ 
      content: lang === 'ar' ? 'لا يوجد أعضاء في التحالف' : 'No members in alliance', 
      ephemeral: true 
    });
    return;
  }

  let message = `**👥 ${lang === 'ar' ? 'أعضاء التحالف' : 'Alliance Members'}**\n\n`;
  
  alliance.members.forEach((member, index) => {
    const joinDate = new Date(member.joinedAt).toLocaleDateString(lang === 'ar' ? 'ar-EG' : 'en-US');
    message += `${index + 1}. <@${member.id}> - **${member.rank}** (${lang === 'ar' ? 'انضم' : 'Joined'}: ${joinDate})\n`;
  });

  await interaction.reply({ 
    content: message, 
    ephemeral: true 
  });
}

async function showDeleteBookingMenu(interaction, type, lang, userId) {
  const bookings = db.getBookings(type);
  const userBookings = bookings.filter(b => b.userId === userId || db.isAdmin(userId));
  
  if (userBookings.length === 0) {
    await interaction.reply({
      content: lang === 'ar' ? '❌ ليس لديك حجوزات لحذفها' : '❌ You have no bookings to delete',
      ephemeral: true
    });
    return;
  }

  const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = await import('discord.js');
  
  let description = lang === 'ar' ? 'اختر الحجز الذي تريد حذفه:\n\n' : 'Select the booking to delete:\n\n';
  
  userBookings.forEach((booking, index) => {
    const start = new Date(booking.startDate).toLocaleDateString(lang === 'ar' ? 'ar-EG' : 'en-US');
    const end = new Date(booking.endDate).toLocaleDateString(lang === 'ar' ? 'ar-EG' : 'en-US');
    description += `**${index + 1}.** ${start} - ${end}\n`;
    if (booking.notes) {
      description += `   📝 ${booking.notes}\n`;
    }
  });

  const embed = new EmbedBuilder()
    .setColor('#ff0000')
    .setTitle(lang === 'ar' ? '🗑️ حذف حجز' : '🗑️ Delete Booking')
    .setDescription(description)
    .setTimestamp();

  const rows = [];
  const buttons = [];
  
  userBookings.forEach((booking, index) => {
    buttons.push(
      new ButtonBuilder()
        .setCustomId(`confirm_delete_${type}_${booking.id}`)
        .setLabel(`${index + 1}`)
        .setStyle(ButtonStyle.Danger)
    );
    
    if ((index + 1) % 5 === 0 || index === userBookings.length - 1) {
      rows.push(new ActionRowBuilder().addComponents(buttons.splice(0)));
    }
  });

  rows.push(
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`cancel_delete_${type}`)
        .setLabel(lang === 'ar' ? '❌ إلغاء' : '❌ Cancel')
        .setStyle(ButtonStyle.Secondary)
    )
  );

  await interaction.reply({
    embeds: [embed],
    components: rows,
    ephemeral: true
  });
}

async function showAllianceManageMenu(interaction, lang) {
  await interaction.reply({
    content: lang === 'ar' 
      ? '⚙️ **إدارة التحالف**\n\n' +
        '**الأوامر المتاحة:**\n' +
        '• `/addmember @user rank` - إضافة عضو\n' +
        '• `/removemember @user` - إزالة عضو\n' +
        '• `/changerank @user rank` - تغيير الرتبة\n' +
        '• `/setalliance name:... tag:... description:...` - تعديل معلومات التحالف\n' +
        '• `/setleader @user` - تعيين القائد (المشرفين فقط)\n\n' +
        '**الرتب المتاحة:** R5, R4, R3, R2, R1'
      : '⚙️ **Alliance Management**\n\n' +
        '**Available Commands:**\n' +
        '• `/addmember @user rank` - Add member\n' +
        '• `/removemember @user` - Remove member\n' +
        '• `/changerank @user rank` - Change rank\n' +
        '• `/setalliance name:... tag:... description:...` - Edit alliance info\n' +
        '• `/setleader @user` - Set leader (Admins only)\n\n' +
        '**Available ranks:** R5, R4, R3, R2, R1',
    ephemeral: true
  });
}

async function showAllianceDetailedInfo(interaction, lang) {
  const alliance = db.getAlliance();
  
  // Count members by rank
  const rankCounts = { R5: 0, R4: 0, R3: 0, R2: 0, R1: 0 };
  alliance.members.forEach(member => {
    if (rankCounts[member.rank] !== undefined) {
      rankCounts[member.rank]++;
    }
  });

  const { EmbedBuilder } = await import('discord.js');
  const embed = new EmbedBuilder()
    .setColor('#0099ff')
    .setTitle(lang === 'ar' ? '🤝 معلومات التحالف التفصيلية' : '🤝 Detailed Alliance Information')
    .setTimestamp();

  embed.addFields(
    { 
      name: lang === 'ar' ? '📛 اسم التحالف' : '📛 Alliance Name', 
      value: alliance.name || (lang === 'ar' ? 'غير محدد' : 'Not set'), 
      inline: true 
    },
    { 
      name: lang === 'ar' ? '🏷️ الوسم' : '🏷️ Tag', 
      value: alliance.tag || (lang === 'ar' ? 'غير محدد' : 'Not set'), 
      inline: true 
    },
    { 
      name: lang === 'ar' ? '👑 القائد' : '👑 Leader', 
      value: alliance.leader ? `<@${alliance.leader}>` : (lang === 'ar' ? 'غير محدد' : 'Not set'), 
      inline: false 
    }
  );

  if (alliance.description) {
    embed.addFields({
      name: lang === 'ar' ? '📝 الوصف' : '📝 Description',
      value: alliance.description,
      inline: false
    });
  }

  embed.addFields(
    { 
      name: lang === 'ar' ? '👥 إجمالي الأعضاء' : '👥 Total Members', 
      value: alliance.members.length.toString(), 
      inline: true 
    },
    { 
      name: lang === 'ar' ? '⭐ توزيع الرتب' : '⭐ Rank Distribution', 
      value: `**R5:** ${rankCounts.R5} | **R4:** ${rankCounts.R4}\n**R3:** ${rankCounts.R3} | **R2:** ${rankCounts.R2}\n**R1:** ${rankCounts.R1}`,
      inline: true 
    }
  );

  if (alliance.members.length > 0) {
    const recentMembers = alliance.members
      .sort((a, b) => new Date(b.joinedAt) - new Date(a.joinedAt))
      .slice(0, 5)
      .map(m => `<@${m.id}> - **${m.rank}**`)
      .join('\n');

    embed.addFields({
      name: lang === 'ar' ? '🆕 أحدث الأعضاء (آخر 5)' : '🆕 Recent Members (Last 5)',
      value: recentMembers,
      inline: false
    });
  }

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function showAllianceRanks(interaction, lang) {
  const alliance = db.getAlliance();
  
  // Group members by rank
  const membersByRank = { R5: [], R4: [], R3: [], R2: [], R1: [] };
  alliance.members.forEach(member => {
    if (membersByRank[member.rank]) {
      membersByRank[member.rank].push(member);
    }
  });

  const { EmbedBuilder } = await import('discord.js');
  const embed = new EmbedBuilder()
    .setColor('#ffd700')
    .setTitle(lang === 'ar' ? '⭐ توزيع رتب التحالف' : '⭐ Alliance Rank Distribution')
    .setDescription(lang === 'ar' 
      ? `إجمالي الأعضاء: **${alliance.members.length}**` 
      : `Total Members: **${alliance.members.length}**`)
    .setTimestamp();

  ['R5', 'R4', 'R3', 'R2', 'R1'].forEach(rank => {
    const members = membersByRank[rank];
    if (members.length > 0) {
      const memberList = members
        .map((m, i) => `${i + 1}. <@${m.id}>`)
        .join('\n');
      
      embed.addFields({
        name: `${rank === 'R5' ? '👑' : rank === 'R4' ? '⭐' : '•'} ${rank} (${members.length})`,
        value: memberList || (lang === 'ar' ? 'لا يوجد' : 'None'),
        inline: false
      });
    }
  });

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function showAllianceCommands(interaction, lang) {
  const { EmbedBuilder } = await import('discord.js');
  const embed = new EmbedBuilder()
    .setColor('#00ff00')
    .setTitle(lang === 'ar' ? '📜 أوامر التحالف' : '📜 Alliance Commands')
    .setDescription(lang === 'ar' 
      ? 'جميع الأوامر المتاحة لإدارة التحالف' 
      : 'All available commands for alliance management')
    .setTimestamp();

  embed.addFields(
    {
      name: lang === 'ar' ? '📊 عرض المعلومات' : '📊 View Information',
      value: lang === 'ar'
        ? '• `/allianceinfo` - معلومات التحالف التفصيلية\n' +
          '• `/members [rank]` - عرض جميع الأعضاء أو حسب الرتبة'
        : '• `/allianceinfo` - Detailed alliance information\n' +
          '• `/members [rank]` - View all members or by rank',
      inline: false
    },
    {
      name: lang === 'ar' ? '👥 إدارة الأعضاء (R4, R5, Admins)' : '👥 Member Management (R4, R5, Admins)',
      value: lang === 'ar'
        ? '• `/addmember @user rank` - إضافة عضو جديد\n' +
          '• `/removemember @user` - إزالة عضو\n' +
          '• `/changerank @user rank` - تغيير رتبة عضو'
        : '• `/addmember @user rank` - Add new member\n' +
          '• `/removemember @user` - Remove member\n' +
          '• `/changerank @user rank` - Change member rank',
      inline: false
    },
    {
      name: lang === 'ar' ? '⚙️ إدارة التحالف (R5, Admins)' : '⚙️ Alliance Settings (R5, Admins)',
      value: lang === 'ar'
        ? '• `/setalliance` - تعديل اسم/وسم/وصف التحالف\n' +
          '  - مثال: `/setalliance name:Phoenix tag:[PHX] description:...`'
        : '• `/setalliance` - Edit alliance name/tag/description\n' +
          '  - Example: `/setalliance name:Phoenix tag:[PHX] description:...`',
      inline: false
    },
    {
      name: lang === 'ar' ? '👑 إدارة القيادة (Admins فقط)' : '👑 Leadership (Admins Only)',
      value: lang === 'ar'
        ? '• `/setleader @user` - تعيين قائد التحالف'
        : '• `/setleader @user` - Set alliance leader',
      inline: false
    }
  );

  embed.setFooter({ 
    text: lang === 'ar' 
      ? 'الرتب المتاحة: R5 (قائد), R4, R3, R2, R1' 
      : 'Available ranks: R5 (leader), R4, R3, R2, R1' 
  });

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function showAdminManageMenu(interaction, lang) {
  const perms = db.getPermissions();
  
  let adminList = lang === 'ar' ? 'لا يوجد مشرفين حالياً' : 'No admins currently';
  if (perms.admins.length > 0) {
    adminList = perms.admins.map((id, i) => `${i + 1}. <@${id}>`).join('\n');
  }

  await interaction.reply({
    content: lang === 'ar'
      ? `👮 **إدارة المشرفين**\n\n` +
        `**المشرفين الحاليين:**\n${adminList}\n\n` +
        `**الأوامر المتاحة:**\n` +
        `• \`/addadmin @user\` - إضافة مشرف\n` +
        `• \`/removeadmin @user\` - حذف مشرف`
      : `👮 **Admin Management**\n\n` +
        `**Current Admins:**\n${adminList}\n\n` +
        `**Available Commands:**\n` +
        `• \`/addadmin @user\` - Add admin\n` +
        `• \`/removeadmin @user\` - Remove admin`,
    ephemeral: true
  });
}

// === Alliance Management Modals ===

async function showAddMemberModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('alliance_modal_add_member')
    .setTitle(lang === 'ar' ? 'إضافة عضو للتحالف' : 'Add Alliance Member');

  const userIdInput = new TextInputBuilder()
    .setCustomId('user_id')
    .setLabel(lang === 'ar' ? 'ID العضو أو @منشن' : 'User ID or @mention')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('123456789012345678 or @user')
    .setRequired(true);

  const rankInput = new TextInputBuilder()
    .setCustomId('rank')
    .setLabel(lang === 'ar' ? 'الرتبة (R1, R2, R3, R4, R5)' : 'Rank (R1, R2, R3, R4, R5)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('R4')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(userIdInput),
    new ActionRowBuilder().addComponents(rankInput)
  );

  await interaction.showModal(modal);
}

async function showRemoveMemberModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('alliance_modal_remove_member')
    .setTitle(lang === 'ar' ? 'إزالة عضو من التحالف' : 'Remove Alliance Member');

  const userIdInput = new TextInputBuilder()
    .setCustomId('user_id')
    .setLabel(lang === 'ar' ? 'ID العضو أو @منشن' : 'User ID or @mention')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('123456789012345678 or @user')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(userIdInput)
  );

  await interaction.showModal(modal);
}

async function showChangeRankModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('alliance_modal_change_rank')
    .setTitle(lang === 'ar' ? 'تغيير رتبة عضو' : 'Change Member Rank');

  const userIdInput = new TextInputBuilder()
    .setCustomId('user_id')
    .setLabel(lang === 'ar' ? 'ID العضو أو @منشن' : 'User ID or @mention')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('123456789012345678 or @user')
    .setRequired(true);

  const rankInput = new TextInputBuilder()
    .setCustomId('rank')
    .setLabel(lang === 'ar' ? 'الرتبة الجديدة (R1-R5)' : 'New Rank (R1-R5)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('R3')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(userIdInput),
    new ActionRowBuilder().addComponents(rankInput)
  );

  await interaction.showModal(modal);
}

async function showSetAllianceInfoModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('alliance_modal_set_info')
    .setTitle(lang === 'ar' ? 'تعديل معلومات التحالف' : 'Edit Alliance Info');

  const alliance = db.getAlliance();

  const nameInput = new TextInputBuilder()
    .setCustomId('name')
    .setLabel(lang === 'ar' ? 'اسم التحالف' : 'Alliance Name')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(alliance.name || 'Phoenix Alliance')
    .setRequired(false);

  const tagInput = new TextInputBuilder()
    .setCustomId('tag')
    .setLabel(lang === 'ar' ? 'الوسم [TAG]' : 'Tag [TAG]')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(alliance.tag || '[PHX]')
    .setRequired(false);

  const descInput = new TextInputBuilder()
    .setCustomId('description')
    .setLabel(lang === 'ar' ? 'الوصف' : 'Description')
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder(alliance.description || 'We are the best alliance!')
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder().addComponents(nameInput),
    new ActionRowBuilder().addComponents(tagInput),
    new ActionRowBuilder().addComponents(descInput)
  );

  await interaction.showModal(modal);
}

async function showSetLeaderModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('alliance_modal_set_leader')
    .setTitle(lang === 'ar' ? 'تعيين قائد التحالف' : 'Set Alliance Leader');

  const userIdInput = new TextInputBuilder()
    .setCustomId('user_id')
    .setLabel(lang === 'ar' ? 'ID العضو أو @منشن' : 'User ID or @mention')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('123456789012345678 or @user')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(userIdInput)
  );

  await interaction.showModal(modal);
}

// === Reminders Modals ===

async function showAddReminderModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('reminder_modal_add')
    .setTitle(lang === 'ar' ? 'إضافة تذكير جديد' : 'Add New Reminder');

  const messageInput = new TextInputBuilder()
    .setCustomId('message')
    .setLabel(lang === 'ar' ? 'رسالة التذكير' : 'Reminder Message')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(lang === 'ar' ? 'تذكير مهم' : 'Important reminder')
    .setRequired(true);

  const timeInput = new TextInputBuilder()
    .setCustomId('time')
    .setLabel(lang === 'ar' ? 'الوقت (YYYY-MM-DD HH:MM)' : 'Time (YYYY-MM-DD HH:MM)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('2024-02-20 15:30')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(messageInput),
    new ActionRowBuilder().addComponents(timeInput)
  );

  await interaction.showModal(modal);
}

async function showRemindersList(interaction, userId, lang) {
  const reminders = db.getReminders(userId);
  
  const { EmbedBuilder } = await import('discord.js');
  const embed = new EmbedBuilder()
    .setColor('#ff6b6b')
    .setTitle(lang === 'ar' ? '📋 جميع تذكيراتك' : '📋 All Your Reminders')
    .setTimestamp();

  if (reminders.length === 0) {
    embed.setDescription(lang === 'ar' ? 'لا توجد تذكيرات' : 'No reminders');
  } else {
    reminders.forEach((r, i) => {
      const date = new Date(r.time).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-US');
      embed.addFields({
        name: `${i + 1}. ${r.message}`,
        value: `⏰ ${date}\n🆔 \`${r.id}\``,
        inline: false
      });
    });
  }

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function showDeleteReminderMenu(interaction, userId, lang) {
  const reminders = db.getReminders(userId);
  
  if (reminders.length === 0) {
    await interaction.reply({ 
      content: lang === 'ar' ? '❌ لا توجد تذكيرات لحذفها' : '❌ No reminders to delete', 
      ephemeral: true 
    });
    return;
  }

  const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = await import('discord.js');
  const embed = new EmbedBuilder()
    .setColor('#ff0000')
    .setTitle(lang === 'ar' ? '🗑️ حذف تذكير' : '🗑️ Delete Reminder')
    .setDescription(lang === 'ar' ? 'اختر التذكير المراد حذفه' : 'Choose a reminder to delete');

  const buttons = [];
  reminders.slice(0, 5).forEach((r, i) => {
    const date = new Date(r.time).toLocaleDateString();
    buttons.push(
      new ButtonBuilder()
        .setCustomId(`reminder_delete_${r.id}`)
        .setLabel(`${i + 1}. ${r.message.substring(0, 20)}... (${date})`)
        .setStyle(ButtonStyle.Danger)
    );
  });

  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) {
    const row = new ActionRowBuilder();
    row.addComponents(buttons[i]);
    if (buttons[i + 1]) row.addComponents(buttons[i + 1]);
    rows.push(row);
  }

  await interaction.reply({ embeds: [embed], components: rows, ephemeral: true });
}

// === Admin Management Modals ===

async function showAddAdminModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('admin_modal_add')
    .setTitle(lang === 'ar' ? 'إضافة مشرف' : 'Add Admin');

  const userIdInput = new TextInputBuilder()
    .setCustomId('user_id')
    .setLabel(lang === 'ar' ? 'ID المستخدم أو @منشن' : 'User ID or @mention')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('123456789012345678 or @user')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(userIdInput)
  );

  await interaction.showModal(modal);
}

async function showRemoveAdminModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('admin_modal_remove')
    .setTitle(lang === 'ar' ? 'حذف مشرف' : 'Remove Admin');

  const userIdInput = new TextInputBuilder()
    .setCustomId('user_id')
    .setLabel(lang === 'ar' ? 'ID المستخدم أو @منشن' : 'User ID or @mention')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('123456789012345678 or @user')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(userIdInput)
  );

  await interaction.showModal(modal);
}

// === Text Edit Modal ===
async function showTextEditModal(interaction, textType, lang) {
  const modal = new ModalBuilder()
    .setCustomId(`text_edit_modal_${textType}`)
    .setTitle(lang === 'ar' ? 'تعديل النص' : 'Edit Text');

  const labels = {
    mainTitle: lang === 'ar' ? 'العنوان الرئيسي' : 'Main Title',
    welcomeMessage: lang === 'ar' ? 'رسالة الترحيب' : 'Welcome Message',
    buttonLabels: lang === 'ar' ? 'أسماء الأزرار (JSON)' : 'Button Labels (JSON)'
  };

  const placeholders = {
    mainTitle: lang === 'ar' ? 'أدخل العنوان الجديد' : 'Enter new title',
    welcomeMessage: lang === 'ar' ? 'أدخل رسالة الترحيب الجديدة' : 'Enter new welcome message',
    buttonLabels: '{"booking": "حجز", "alliance": "تحالف"}'
  };

  const textInput = new TextInputBuilder()
    .setCustomId('text_value')
    .setLabel(labels[textType] || textType)
    .setStyle(textType === 'buttonLabels' || textType === 'welcomeMessage' ? TextInputStyle.Paragraph : TextInputStyle.Short)
    .setPlaceholder(placeholders[textType] || '')
    .setRequired(true);

  const currentValue = db.getCustomTexts ? db.getCustomTexts()[textType] : null;
  if (currentValue) {
    textInput.setValue(typeof currentValue === 'object' ? JSON.stringify(currentValue) : currentValue);
  }

  modal.addComponents(
    new ActionRowBuilder().addComponents(textInput)
  );

  await interaction.showModal(modal);
}

// === Ban User Modal ===
async function showBanUserModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('security_ban_modal')
    .setTitle(lang === 'ar' ? 'حظر مستخدم' : 'Ban User');

  const userIdInput = new TextInputBuilder()
    .setCustomId('user_id')
    .setLabel(lang === 'ar' ? 'ID المستخدم' : 'User ID')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('123456789012345678')
    .setRequired(true);

  const reasonInput = new TextInputBuilder()
    .setCustomId('reason')
    .setLabel(lang === 'ar' ? 'السبب' : 'Reason')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(lang === 'ar' ? 'سبب الحظر' : 'Reason for ban')
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder().addComponents(userIdInput),
    new ActionRowBuilder().addComponents(reasonInput)
  );

  await interaction.showModal(modal);
}

// === Unban User Modal ===
async function showUnbanUserModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('security_unban_modal')
    .setTitle(lang === 'ar' ? 'إلغاء حظر مستخدم' : 'Unban User');

  const userIdInput = new TextInputBuilder()
    .setCustomId('user_id')
    .setLabel(lang === 'ar' ? 'ID المستخدم' : 'User ID')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('123456789012345678')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(userIdInput)
  );

  await interaction.showModal(modal);
}

// === Advanced Member Modal ===
async function showAdvancedMemberModal(interaction, lang, action = 'add') {
  const modal = new ModalBuilder()
    .setCustomId(action === 'add' ? 'modal_member_add_advanced' : 'modal_member_edit_game')
    .setTitle(lang === 'ar' 
      ? (action === 'add' ? 'إضافة عضو جديد' : 'تعديل بيانات العضو')
      : (action === 'add' ? 'Add New Member' : 'Edit Member Data'));

  const gameIdInput = new TextInputBuilder()
    .setCustomId('game_id')
    .setLabel(lang === 'ar' ? 'ID اللعبة' : 'Game ID')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('123456789')
    .setRequired(true);

  const gameNameInput = new TextInputBuilder()
    .setCustomId('game_name')
    .setLabel(lang === 'ar' ? 'اسم اللعبة' : 'Game Name')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(lang === 'ar' ? 'اسم الحساب في اللعبة' : 'In-game account name')
    .setRequired(true);

  const powerInput = new TextInputBuilder()
    .setCustomId('power')
    .setLabel(lang === 'ar' ? 'القوة (بالملايين)' : 'Power (in millions)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('50')
    .setRequired(false);

  const furnaceInput = new TextInputBuilder()
    .setCustomId('furnace_level')
    .setLabel(lang === 'ar' ? 'مستوى الفرن' : 'Furnace Level')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('30')
    .setRequired(false);

  const rankInput = new TextInputBuilder()
    .setCustomId('rank')
    .setLabel(lang === 'ar' ? 'الرتبة (R1-R5)' : 'Rank (R1-R5)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('R4')
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder().addComponents(gameIdInput),
    new ActionRowBuilder().addComponents(gameNameInput),
    new ActionRowBuilder().addComponents(powerInput),
    new ActionRowBuilder().addComponents(furnaceInput),
    new ActionRowBuilder().addComponents(rankInput)
  );

  await interaction.showModal(modal);
}

// === Member Profile Modal ===
async function showMemberProfileModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('modal_member_view_profile')
    .setTitle(lang === 'ar' ? 'عرض ملف العضو' : 'View Member Profile');

  const searchInput = new TextInputBuilder()
    .setCustomId('search_query')
    .setLabel(lang === 'ar' ? 'ID اللعبة أو الاسم' : 'Game ID or Name')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(lang === 'ar' ? 'ابحث بـ ID اللعبة أو الاسم' : 'Search by Game ID or Name')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(searchInput)
  );

  await interaction.showModal(modal);
}

// === Edit Member Modal ===
async function showEditMemberModal(interaction, memberId, lang) {
  const alliance = db.getAlliance();
  const member = alliance.members?.find(m => m.id === memberId || m.gameId === memberId);
  
  const modal = new ModalBuilder()
    .setCustomId(`modal_member_edit_${memberId}`)
    .setTitle(lang === 'ar' ? 'تعديل بيانات العضو' : 'Edit Member Data');

  const gameIdInput = new TextInputBuilder()
    .setCustomId('game_id')
    .setLabel(lang === 'ar' ? 'ID اللعبة' : 'Game ID')
    .setStyle(TextInputStyle.Short)
    .setValue(member?.gameId || '')
    .setRequired(true);

  const gameNameInput = new TextInputBuilder()
    .setCustomId('game_name')
    .setLabel(lang === 'ar' ? 'اسم اللعبة' : 'Game Name')
    .setStyle(TextInputStyle.Short)
    .setValue(member?.gameName || member?.name || '')
    .setRequired(true);

  const powerInput = new TextInputBuilder()
    .setCustomId('power')
    .setLabel(lang === 'ar' ? 'القوة (بالملايين)' : 'Power (in millions)')
    .setStyle(TextInputStyle.Short)
    .setValue(member?.power ? String(member.power / 1000000) : '')
    .setRequired(false);

  const furnaceInput = new TextInputBuilder()
    .setCustomId('furnace_level')
    .setLabel(lang === 'ar' ? 'مستوى الفرن' : 'Furnace Level')
    .setStyle(TextInputStyle.Short)
    .setValue(member?.furnaceLevel?.toString() || '')
    .setRequired(false);

  const rankInput = new TextInputBuilder()
    .setCustomId('rank')
    .setLabel(lang === 'ar' ? 'الرتبة (R1-R5)' : 'Rank (R1-R5)')
    .setStyle(TextInputStyle.Short)
    .setValue(member?.rank || 'R1')
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder().addComponents(gameIdInput),
    new ActionRowBuilder().addComponents(gameNameInput),
    new ActionRowBuilder().addComponents(powerInput),
    new ActionRowBuilder().addComponents(furnaceInput),
    new ActionRowBuilder().addComponents(rankInput)
  );

  await interaction.showModal(modal);
}

// === Advanced Alliance Functions ===

async function showDetailedMembersList(interaction, lang) {
  const alliance = db.getAlliance();
  const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = await import('discord.js');

  if (!alliance.members || alliance.members.length === 0) {
    await interaction.reply({ content: lang === 'ar' ? '❌ لا يوجد أعضاء' : '❌ No members', ephemeral: true });
    return;
  }

  let description = '';
  alliance.members.forEach((member, index) => {
    const joinDate = new Date(member.joinedAt).toLocaleDateString(lang === 'ar' ? 'ar-EG' : 'en-US');
    description += `**${index + 1}.** <@${member.id}>\n`;
    description += `   └ ${lang === 'ar' ? 'رتبة' : 'Rank'}: **${member.rank}** | ${lang === 'ar' ? 'انضم' : 'Joined'}: ${joinDate}\n`;
  });

  const embed = new EmbedBuilder()
    .setTitle(`👥 ${lang === 'ar' ? 'قائمة الأعضاء التفصيلية' : 'Detailed Members List'}`)
    .setDescription(description)
    .setColor('#4A90E2')
    .setFooter({ text: lang === 'ar' ? `إجمالي: ${alliance.members.length} عضو` : `Total: ${alliance.members.length} members` })
    .setTimestamp();

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function showAllianceActivity(interaction, lang) {
  const alliance = db.getAlliance();
  const bookings = db.getBookings();
  const { EmbedBuilder } = await import('discord.js');

  // حساب الأنشطة
  let totalBookings = 0;
  for (const type in bookings) {
    if (Array.isArray(bookings[type])) {
      totalBookings += bookings[type].length;
    }
  }

  const recentMembers = alliance.members
    ?.sort((a, b) => new Date(b.joinedAt) - new Date(a.joinedAt))
    .slice(0, 5)
    .map(m => `• <@${m.id}>`)
    .join('\n') || (lang === 'ar' ? 'لا يوجد' : 'None');

  const embed = new EmbedBuilder()
    .setTitle(`📊 ${lang === 'ar' ? 'نشاط التحالف' : 'Alliance Activity'}`)
    .setColor('#E67E22')
    .addFields(
      {
        name: lang === 'ar' ? '📅 إجمالي الحجوزات' : '📅 Total Bookings',
        value: totalBookings.toString(),
        inline: true
      },
      {
        name: lang === 'ar' ? '👥 عدد الأعضاء' : '👥 Member Count',
        value: (alliance.members?.length || 0).toString(),
        inline: true
      },
      {
        name: lang === 'ar' ? '🆕 أحدث الأعضاء' : '🆕 Recent Members',
        value: recentMembers,
        inline: false
      }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function exportAllianceData(interaction, lang) {
  const alliance = db.getAlliance();
  const bookings = db.getBookings();

  const data = {
    alliance: alliance,
    bookings: bookings,
    exportedAt: new Date().toISOString()
  };

  const jsonData = JSON.stringify(data, null, 2);
  const { AttachmentBuilder } = await import('discord.js');
  const attachment = new AttachmentBuilder(Buffer.from(jsonData), { name: 'alliance_data.json' });

  await interaction.reply({ 
    content: lang === 'ar' ? '📥 تم تصدير بيانات التحالف' : '📥 Alliance data exported',
    files: [attachment],
    ephemeral: true
  });
}

// === Alliance Logs Functions ===

async function showSetLogChannelModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('log_channel_modal')
    .setTitle(lang === 'ar' ? 'تعيين قناة السجلات' : 'Set Log Channel');

  const channelInput = new TextInputBuilder()
    .setCustomId('channel_id')
    .setLabel(lang === 'ar' ? 'ID القناة أو #منشن' : 'Channel ID or #mention')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('123456789012345678 or #channel')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(channelInput)
  );

  await interaction.showModal(modal);
}

async function showCurrentLogChannel(interaction, lang) {
  const channelId = db.getLogChannel(interaction.guildId);
  const { EmbedBuilder } = await import('discord.js');

  const embed = new EmbedBuilder()
    .setTitle(lang === 'ar' ? '📊 قناة السجلات الحالية' : '📊 Current Log Channel')
    .setColor('#4A90E2');

  if (channelId) {
    embed.setDescription(`${lang === 'ar' ? 'القناة' : 'Channel'}: <#${channelId}>`);
  } else {
    embed.setDescription(lang === 'ar' ? '❌ لم يتم تعيين قناة السجلات' : '❌ No log channel set');
  }

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function removeLogChannel(interaction, lang) {
  db.removeLogChannel(interaction.guildId);
  await interaction.reply({ 
    content: lang === 'ar' ? '✅ تم إزالة قناة السجلات' : '✅ Log channel removed',
    ephemeral: true
  });
}

async function showRecentLogs(interaction, lang) {
  const logs = db.getRecentLogs(10);
  const { EmbedBuilder } = await import('discord.js');

  const embed = new EmbedBuilder()
    .setTitle(lang === 'ar' ? '📖 آخر السجلات' : '📖 Recent Logs')
    .setColor('#9B59B6');

  if (logs.length === 0) {
    embed.setDescription(lang === 'ar' ? 'لا توجد سجلات' : 'No logs available');
  } else {
    let description = '';
    logs.forEach((log, index) => {
      const time = new Date(log.timestamp).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-US');
      description += `**${index + 1}.** ${log.action} - <@${log.userId}>\n`;
      description += `   └ ${time}\n`;
    });
    embed.setDescription(description);
  }

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

// === Ministries Functions ===

async function showAddMinistryModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('ministry_modal_add')
    .setTitle(lang === 'ar' ? 'إضافة وزارة' : 'Add Ministry');

  const nameInput = new TextInputBuilder()
    .setCustomId('ministry_name')
    .setLabel(lang === 'ar' ? 'اسم الوزارة' : 'Ministry Name')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const descInput = new TextInputBuilder()
    .setCustomId('ministry_description')
    .setLabel(lang === 'ar' ? 'الوصف' : 'Description')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(nameInput),
    new ActionRowBuilder().addComponents(descInput)
  );

  await interaction.showModal(modal);
}

async function showMinistriesList(interaction, lang) {
  const ministries = db.getMinistries();
  const { EmbedBuilder } = await import('discord.js');

  const embed = new EmbedBuilder()
    .setTitle(lang === 'ar' ? '🏛️ قائمة الوزارات' : '🏛️ Ministries List')
    .setColor('#9B59B6');

  if (!ministries || ministries.length === 0) {
    embed.setDescription(lang === 'ar' ? 'لا توجد وزارات' : 'No ministries available');
  } else {
    let description = '';
    ministries.forEach((ministry, index) => {
      description += `**${index + 1}. ${ministry.name}**\n`;
      description += `   ${ministry.description}\n`;
      if (ministry.minister) {
        description += `   👤 ${lang === 'ar' ? 'الوزير' : 'Minister'}: <@${ministry.minister}>\n`;
      }
      description += '\n';
    });
    embed.setDescription(description);
  }

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function showEditMinistryMenu(interaction, lang) {
  await interaction.reply({
    content: lang === 'ar' ? '⚠️ استخدم الأمر: /ministries ثم اختر تعديل' : '⚠️ Use command: /ministries then choose edit',
    ephemeral: true
  });
}

async function showDeleteMinistryMenu(interaction, lang) {
  await interaction.reply({
    content: lang === 'ar' ? '⚠️ استخدم الأمر: /ministries ثم اختر حذف' : '⚠️ Use command: /ministries then choose delete',
    ephemeral: true
  });
}

async function showScheduleActivityModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('schedule_activity_modal')
    .setTitle(lang === 'ar' ? 'جدولة نشاط' : 'Schedule Activity');

  const activityInput = new TextInputBuilder()
    .setCustomId('activity_name')
    .setLabel(lang === 'ar' ? 'اسم النشاط' : 'Activity Name')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const timeInput = new TextInputBuilder()
    .setCustomId('activity_time')
    .setLabel(lang === 'ar' ? 'الوقت (YYYY-MM-DD HH:MM)' : 'Time (YYYY-MM-DD HH:MM)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('2024-02-15 14:30')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(activityInput),
    new ActionRowBuilder().addComponents(timeInput)
  );

  await interaction.showModal(modal);
}

async function showAssignMinisterMenu(interaction, lang) {
  await interaction.reply({
    content: lang === 'ar' ? '⚠️ استخدم الأمر: /ministries ثم اختر تعيين وزير' : '⚠️ Use command: /ministries then choose assign minister',
    ephemeral: true
  });
}

// === Advanced Schedule Functions ===

async function showCreateScheduledAlertModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('scheduled_alert_modal')
    .setTitle(lang === 'ar' ? 'إنشاء تنبيه مجدول' : 'Create Scheduled Alert');

  const messageInput = new TextInputBuilder()
    .setCustomId('alert_message')
    .setLabel(lang === 'ar' ? 'رسالة التنبيه' : 'Alert Message')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const timeInput = new TextInputBuilder()
    .setCustomId('alert_time')
    .setLabel(lang === 'ar' ? 'الوقت (YYYY-MM-DD HH:MM)' : 'Time (YYYY-MM-DD HH:MM)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('2024-02-15 14:30')
    .setRequired(true);

  const repeatInput = new TextInputBuilder()
    .setCustomId('alert_repeat')
    .setLabel(lang === 'ar' ? 'تكرار (بالساعات، 0 = لا)' : 'Repeat (in hours, 0 = no)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('0')
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder().addComponents(messageInput),
    new ActionRowBuilder().addComponents(timeInput),
    new ActionRowBuilder().addComponents(repeatInput)
  );

  await interaction.showModal(modal);
}

async function showSchedulesList(interaction, lang) {
  const schedules = db.getScheduledBookings();
  const { EmbedBuilder } = await import('discord.js');

  const embed = new EmbedBuilder()
    .setTitle(lang === 'ar' ? '📅 قائمة الجداول' : '📅 Schedules List')
    .setColor('#E67E22');

  if (!schedules || schedules.length === 0) {
    embed.setDescription(lang === 'ar' ? 'لا توجد جداول' : 'No schedules available');
  } else {
    let description = '';
    schedules.forEach((schedule, index) => {
      const time = new Date(schedule.startTime).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-US');
      description += `**${index + 1}.** ${lang === 'ar' ? 'النشاط' : 'Activity'}: ${schedule.activityId}\n`;
      description += `   └ ${time} | ${schedule.repeat ? '🔄' : '⏱️'}\n`;
    });
    embed.setDescription(description);
  }

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function showEditScheduleMenu(interaction, lang) {
  await interaction.reply({
    content: lang === 'ar' ? '⚠️ استخدم الأمر: /schedule ثم اختر تعديل' : '⚠️ Use command: /schedule then choose edit',
    ephemeral: true
  });
}

async function showDeleteScheduleMenu(interaction, lang) {
  await interaction.reply({
    content: lang === 'ar' ? '⚠️ استخدم الأمر: /schedule ثم اختر حذف' : '⚠️ Use command: /schedule then choose delete',
    ephemeral: true
  });
}

async function showAdvancedScheduleModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('advanced_schedule_modal')
    .setTitle(lang === 'ar' ? 'جدولة متقدمة' : 'Advanced Scheduling');

  const activityInput = new TextInputBuilder()
    .setCustomId('schedule_activity')
    .setLabel(lang === 'ar' ? 'النشاط' : 'Activity')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const timeInput = new TextInputBuilder()
    .setCustomId('schedule_time')
    .setLabel(lang === 'ar' ? 'الوقت (YYYY-MM-DD HH:MM)' : 'Time (YYYY-MM-DD HH:MM)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('2024-02-15 14:30')
    .setRequired(true);

  const intervalInput = new TextInputBuilder()
    .setCustomId('schedule_interval')
    .setLabel(lang === 'ar' ? 'فترة التكرار (بالساعات)' : 'Repeat Interval (in hours)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('24')
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder().addComponents(activityInput),
    new ActionRowBuilder().addComponents(timeInput),
    new ActionRowBuilder().addComponents(intervalInput)
  );

  await interaction.showModal(modal);
}

async function toggleAutoRepeat(interaction, lang) {
  await interaction.reply({
    content: lang === 'ar' ? '⚠️ هذه الميزة قيد التطوير' : '⚠️ This feature is under development',
    ephemeral: true
  });
}

// === New Members Management Functions (with different names to avoid conflicts) ===

async function showNewAddMemberModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('modal_member_add')
    .setTitle(lang === 'ar' ? 'إضافة عضو جديد' : 'Add New Member');

  const userInput = new TextInputBuilder()
    .setCustomId('member_user')
    .setLabel(lang === 'ar' ? 'المستخدم (@منشن أو ID)' : 'User (@mention or ID)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('@user or 123456789')
    .setRequired(true);

  const rankInput = new TextInputBuilder()
    .setCustomId('member_rank')
    .setLabel(lang === 'ar' ? 'الرتبة' : 'Rank')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('R1, R2, R3, R4, R5')
    .setValue('R1')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(userInput),
    new ActionRowBuilder().addComponents(rankInput)
  );

  await interaction.showModal(modal);
}

async function showNewRemoveMemberModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('modal_member_remove')
    .setTitle(lang === 'ar' ? 'إزالة عضو' : 'Remove Member');

  const userInput = new TextInputBuilder()
    .setCustomId('member_user')
    .setLabel(lang === 'ar' ? 'المستخدم (@منشن أو ID)' : 'User (@mention or ID)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('@user or 123456789')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(userInput)
  );

  await interaction.showModal(modal);
}

async function showNewChangeRankModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('modal_member_rank')
    .setTitle(lang === 'ar' ? 'تغيير رتبة عضو' : 'Change Member Rank');

  const userInput = new TextInputBuilder()
    .setCustomId('member_user')
    .setLabel(lang === 'ar' ? 'المستخدم (@منشن أو ID)' : 'User (@mention or ID)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('@user or 123456789')
    .setRequired(true);

  const rankInput = new TextInputBuilder()
    .setCustomId('member_rank')
    .setLabel(lang === 'ar' ? 'الرتبة الجديدة' : 'New Rank')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('R1, R2, R3, R4, R5')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(userInput),
    new ActionRowBuilder().addComponents(rankInput)
  );

  await interaction.showModal(modal);
}

async function showAllMembersList(interaction, lang) {
  const alliance = db.getAlliance();
  const { EmbedBuilder } = await import('discord.js');

  if (!alliance.members || alliance.members.length === 0) {
    await interaction.reply({ 
      content: lang === 'ar' ? '❌ لا يوجد أعضاء' : '❌ No members', 
      ephemeral: true 
    });
    return;
  }

  // Group by rank
  const byRank = {};
  alliance.members.forEach(m => {
    if (!byRank[m.rank]) byRank[m.rank] = [];
    byRank[m.rank].push(m);
  });

  const embed = new EmbedBuilder()
    .setTitle(lang === 'ar' ? `👥 جميع الأعضاء (${alliance.members.length})` : `👥 All Members (${alliance.members.length})`)
    .setColor('#3498db')
    .setTimestamp();

  for (const rank of ['R5', 'R4', 'R3', 'R2', 'R1']) {
    if (byRank[rank] && byRank[rank].length > 0) {
      const members = byRank[rank].map((m, i) => {
        const joinDate = new Date(m.joinedAt).toLocaleDateString(lang === 'ar' ? 'ar-EG' : 'en-US');
        return `${i + 1}. <@${m.id}> - ${joinDate}`;
      }).join('\n');
      
      embed.addFields({
        name: `⭐ ${rank} (${byRank[rank].length})`,
        value: members,
        inline: false
      });
    }
  }

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function showMemberSearchModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('modal_member_search')
    .setTitle(lang === 'ar' ? 'بحث عن عضو' : 'Search Member');

  const searchInput = new TextInputBuilder()
    .setCustomId('search_query')
    .setLabel(lang === 'ar' ? 'اسم المستخدم أو ID' : 'Username or ID')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(lang === 'ar' ? 'اكتب للبحث...' : 'Type to search...')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(searchInput)
  );

  await interaction.showModal(modal);
}

async function showDeleteMinistryModal(interaction, lang) {
  const ministries = db.getMinistries();
  
  if (!ministries || ministries.length === 0) {
    await interaction.reply({
      content: lang === 'ar' ? '❌ لا توجد وزارات لحذفها' : '❌ No ministries to delete',
      ephemeral: true
    });
    return;
  }

  const modal = new ModalBuilder()
    .setCustomId('modal_ministry_delete')
    .setTitle(lang === 'ar' ? 'حذف وزارة' : 'Delete Ministry');

  const nameInput = new TextInputBuilder()
    .setCustomId('ministry_name')
    .setLabel(lang === 'ar' ? 'اسم الوزارة' : 'Ministry Name')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(lang === 'ar' ? 'أدخل اسم الوزارة...' : 'Enter ministry name...')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(nameInput)
  );

  await interaction.showModal(modal);
}

async function showAssignMinisterModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('modal_ministry_assign')
    .setTitle(lang === 'ar' ? 'تعيين وزير' : 'Assign Minister');

  const ministryInput = new TextInputBuilder()
    .setCustomId('ministry_name')
    .setLabel(lang === 'ar' ? 'اسم الوزارة' : 'Ministry Name')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const userInput = new TextInputBuilder()
    .setCustomId('minister_user')
    .setLabel(lang === 'ar' ? 'المستخدم (@منشن أو ID)' : 'User (@mention or ID)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('@user or 123456789')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(ministryInput),
    new ActionRowBuilder().addComponents(userInput)
  );

  await interaction.showModal(modal);
}

// Add Guild Modal
async function showAddGuildModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('modal_guild_add')
    .setTitle(lang === 'ar' ? 'إضافة سيرفر' : 'Add Server');

  const idInput = new TextInputBuilder()
    .setCustomId('guild_id')
    .setLabel(lang === 'ar' ? 'معرف السيرفر (Guild ID)' : 'Server ID (Guild ID)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('1234567890123456789')
    .setRequired(true)
    .setMinLength(17)
    .setMaxLength(20);

  const nameInput = new TextInputBuilder()
    .setCustomId('guild_name')
    .setLabel(lang === 'ar' ? 'اسم السيرفر' : 'Server Name')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(lang === 'ar' ? 'اسم للتعريف فقط' : 'Name for reference only')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(idInput),
    new ActionRowBuilder().addComponents(nameInput)
  );

  await interaction.showModal(modal);
}

// Remove Guild Modal
async function showRemoveGuildModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('modal_guild_remove')
    .setTitle(lang === 'ar' ? 'إزالة سيرفر' : 'Remove Server');

  const idInput = new TextInputBuilder()
    .setCustomId('guild_id')
    .setLabel(lang === 'ar' ? 'معرف السيرفر (Guild ID)' : 'Server ID (Guild ID)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('1234567890123456789')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(idInput)
  );

  await interaction.showModal(modal);
}

// Alliance Register Modal
async function showAllianceRegisterModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('modal_alliance_register')
    .setTitle(lang === 'ar' ? 'تسجيل التحالف' : 'Register Alliance');

  const nameInput = new TextInputBuilder()
    .setCustomId('alliance_name')
    .setLabel(lang === 'ar' ? 'اسم التحالف' : 'Alliance Name')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(lang === 'ar' ? 'مثال: أبطال الشرق' : 'Example: Eastern Heroes')
    .setRequired(true)
    .setMaxLength(50);

  const tagInput = new TextInputBuilder()
    .setCustomId('alliance_tag')
    .setLabel(lang === 'ar' ? 'تاق التحالف (3-4 أحرف)' : 'Alliance Tag (3-4 chars)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(lang === 'ar' ? 'مثال: [EH]' : 'Example: [EH]')
    .setRequired(true)
    .setMinLength(3)
    .setMaxLength(6);

  const descInput = new TextInputBuilder()
    .setCustomId('alliance_desc')
    .setLabel(lang === 'ar' ? 'وصف التحالف (اختياري)' : 'Description (optional)')
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder(lang === 'ar' ? 'أدخل وصفاً للتحالف...' : 'Enter alliance description...')
    .setRequired(false)
    .setMaxLength(500);

  modal.addComponents(
    new ActionRowBuilder().addComponents(nameInput),
    new ActionRowBuilder().addComponents(tagInput),
    new ActionRowBuilder().addComponents(descInput)
  );

  await interaction.showModal(modal);
}

// Ministry Appointment Modal
async function showAppointmentModal(interaction, type, lang) {
  const now = new Date();
  const currentMonth = now.getMonth() + 1;
  const currentYear = now.getFullYear();
  const alliance = db.getAlliance();
  
  const ministryNames = {
    building: lang === 'ar' ? 'البناء' : 'Building',
    research: lang === 'ar' ? 'البحث' : 'Research',
    training: lang === 'ar' ? 'التدريب' : 'Training'
  };

  const modal = new ModalBuilder()
    .setCustomId(`modal_appointment_${type}`)
    .setTitle(lang === 'ar' ? `📅 ${ministryNames[type]}` : `📅 ${ministryNames[type]}`);

  const memberInput = new TextInputBuilder()
    .setCustomId('appointment_member')
    .setLabel(lang === 'ar' ? 'اسم العضو' : 'Member Name')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(interaction.user.username)
    .setValue(interaction.user.username)
    .setRequired(true)
    .setMaxLength(50);

  const memberIdInput = new TextInputBuilder()
    .setCustomId('appointment_member_id')
    .setLabel(lang === 'ar' ? 'ID العضو' : 'Member ID')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(interaction.user.id)
    .setValue(interaction.user.id)
    .setRequired(true);

  const dayMonthInput = new TextInputBuilder()
    .setCustomId('appointment_date')
    .setLabel(lang === 'ar' ? `اليوم/الشهر (${currentYear})` : `Day/Month (${currentYear})`)
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(`${now.getDate()}/${currentMonth}`)
    .setRequired(true)
    .setMinLength(3)
    .setMaxLength(5);

  const timeInput = new TextInputBuilder()
    .setCustomId('appointment_time')
    .setLabel(lang === 'ar' ? 'الوقت: 00:00, 00:30... 23:30' : 'Time: 00:00, 00:30... 23:30')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('14:00')
    .setRequired(true)
    .setMinLength(4)
    .setMaxLength(5);

  modal.addComponents(
    new ActionRowBuilder().addComponents(memberInput),
    new ActionRowBuilder().addComponents(memberIdInput),
    new ActionRowBuilder().addComponents(dayMonthInput),
    new ActionRowBuilder().addComponents(timeInput)
  );

  await interaction.showModal(modal);
}

async function showAllAppointments(interaction, lang) {
  const appointments = db.getBookings('ministry') || [];
  let content = lang === 'ar' ? '**📋 جميع المواعيد:**\n\n' : '**📋 All Appointments:**\n\n';
  
  if (appointments.length === 0) {
    content += lang === 'ar' ? '❌ لا توجد مواعيد' : '❌ No appointments';
  } else {
    appointments.forEach((apt, i) => {
      content += `**${i + 1}.** ${apt.ministry || apt.type} | ${apt.date} ${apt.time} | ${apt.userName}\n`;
    });
  }
  await interaction.reply({ content, ephemeral: true });
}

async function showDeleteAppointmentModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('modal_appointment_delete')
    .setTitle(lang === 'ar' ? 'حذف موعد' : 'Delete');

  const idInput = new TextInputBuilder()
    .setCustomId('appointment_id')
    .setLabel(lang === 'ar' ? 'رقم الموعد' : 'Number')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  modal.addComponents(new ActionRowBuilder().addComponents(idInput));
  await interaction.showModal(modal);
}

async function showEditReminderMessageModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('modal_reminder_edit')
    .setTitle(lang === 'ar' ? 'تعديل تذكير' : 'Edit Reminder');

  const idInput = new TextInputBuilder()
    .setCustomId('reminder_id')
    .setLabel(lang === 'ar' ? 'الرقم' : 'Number')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const messageInput = new TextInputBuilder()
    .setCustomId('reminder_message')
    .setLabel(lang === 'ar' ? 'الرسالة' : 'Message')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(idInput),
    new ActionRowBuilder().addComponents(messageInput)
  );
  await interaction.showModal(modal);
}

async function showSetReminderTimeModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('modal_reminder_time')
    .setTitle(lang === 'ar' ? 'وقت التذكير' : 'Time');

  const idInput = new TextInputBuilder()
    .setCustomId('reminder_id')
    .setLabel(lang === 'ar' ? 'الرقم' : 'Number')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const timeInput = new TextInputBuilder()
    .setCustomId('reminder_before')
    .setLabel(lang === 'ar' ? 'قبل (5m,15m,30m,1h,1d)' : 'Before (5m,15m,30m,1h,1d)')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(idInput),
    new ActionRowBuilder().addComponents(timeInput)
  );
  await interaction.showModal(modal);
}

async function showMoveButtonModal(interaction, direction, lang) {
  const modal = new ModalBuilder()
    .setCustomId(`modal_layout_move_${direction}`)
    .setTitle(lang === 'ar' ? 'نقل زر' : 'Move');

  const rowInput = new TextInputBuilder()
    .setCustomId('row_number')
    .setLabel(lang === 'ar' ? 'الصف (1-4)' : 'Row (1-4)')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const buttonInput = new TextInputBuilder()
    .setCustomId('button_index')
    .setLabel(lang === 'ar' ? 'الزر (1-3)' : 'Button (1-3)')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(rowInput),
    new ActionRowBuilder().addComponents(buttonInput)
  );
  await interaction.showModal(modal);
}

async function showSwapButtonsModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('modal_layout_swap')
    .setTitle(lang === 'ar' ? 'تبديل' : 'Swap');

  const pos1Input = new TextInputBuilder()
    .setCustomId('position1')
    .setLabel(lang === 'ar' ? 'موضع1 (صف,زر)' : 'Pos1 (row,btn)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('1,2')
    .setRequired(true);

  const pos2Input = new TextInputBuilder()
    .setCustomId('position2')
    .setLabel(lang === 'ar' ? 'موضع2 (صف,زر)' : 'Pos2 (row,btn)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('2,1')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(pos1Input),
    new ActionRowBuilder().addComponents(pos2Input)
  );
  await interaction.showModal(modal);
}

async function showEditLabelsModal(interaction, lang) {
  const modal = new ModalBuilder()
    .setCustomId('modal_layout_edit_labels')
    .setTitle(lang === 'ar' ? 'تعديل نص زر' : 'Edit Button Label');

  const buttonInput = new TextInputBuilder()
    .setCustomId('button_id')
    .setLabel(lang === 'ar' ? 'رقم الزر: 1=تحالف, 2=مواعيد, 3=أعضاء...' : 'Button: 1=Alliance, 2=Appt, 3=Members...')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('1')
    .setRequired(true)
    .setMinLength(1)
    .setMaxLength(2);

  const labelArInput = new TextInputBuilder()
    .setCustomId('label_ar')
    .setLabel(lang === 'ar' ? 'النص العربي الجديد' : 'New Arabic Text')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(lang === 'ar' ? '🤝 التحالف' : '🤝 التحالف')
    .setRequired(true);

  const labelEnInput = new TextInputBuilder()
    .setCustomId('label_en')
    .setLabel(lang === 'ar' ? 'النص الإنجليزي الجديد' : 'New English Text')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('🤝 Alliance')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(buttonInput),
    new ActionRowBuilder().addComponents(labelArInput),
    new ActionRowBuilder().addComponents(labelEnInput)
  );
  
  await interaction.showModal(modal);
}

// About menu
async function showAboutMenu(interaction, lang) {
  const aboutData = db.getAboutData() || {};
  const content = aboutData.content || (lang === 'ar' 
    ? '**معلومات البوت**\n\nبوت إدارة التحالف\nالإصدار: 2.1.0'
    : '**Bot Information**\n\nAlliance Management Bot\nVersion: 2.1.0');
  
  await interaction.reply({ content, ephemeral: true });
}

// Check for bot updates
async function checkBotUpdate(interaction, lang) {
  await interaction.reply({ 
    content: lang === 'ar' 
      ? '✅ البوت محدث إلى أحدث إصدار (2.1.0)\n\nللتحديث اليدوي:\n```\ngit pull origin main\nnpm install\n```'
      : '✅ Bot is up to date (Version 2.1.0)\n\nFor manual update:\n```\ngit pull origin main\nnpm install\n```',
    ephemeral: true 
  });
}

// Button number mapping for edit labels
const buttonNumberMap = {
  1: 'menu_alliance',
  2: 'menu_ministry_appointments',
  3: 'menu_members',
  4: 'menu_logs',
  5: 'menu_schedule',
  6: 'menu_reminders',
  7: 'menu_permissions',
  8: 'menu_stats',
  9: 'menu_settings',
  10: 'menu_help',
  11: 'lang_switch'
};

// Extract selected button position from embed description
function extractSelectedButton(description) {
  if (!description) return null;
  const match = description.match(/✨.*?(\d+),(\d+)/);
  if (match) return `${match[1]},${match[2]}`;
  
  // Try to find selected button indicator
  const selectMatch = description.match(/\*\*\[\s*(\d+)\./);
  if (selectMatch) {
    // Convert button number to position
    const layout = db.getButtonLayout();
    let btnNum = 0;
    for (let r = 0; r < layout.rows.length; r++) {
      for (let c = 0; c < layout.rows[r].length; c++) {
        btnNum++;
        if (btnNum === parseInt(selectMatch[1])) {
          return `${r},${c}`;
        }
      }
    }
  }
  return null;
}

// Move button in specified direction
async function moveButtonDirection(interaction, selectedPos, direction, userId, lang) {
  if (!db.isOwner(userId)) {
    await interaction.reply({ content: lang === 'ar' ? '❌ ليس لديك صلاحية' : '❌ No permission', ephemeral: true });
    return;
  }

  const layout = db.getButtonLayout();
  const [row, col] = selectedPos.split(',').map(Number);
  
  let targetRow = row;
  let targetCol = col;
  
  switch (direction) {
    case 'up':
      targetRow = row > 0 ? row - 1 : row;
      break;
    case 'down':
      targetRow = row < layout.rows.length - 1 ? row + 1 : row;
      break;
    case 'left':
      if (col > 0) {
        targetCol = col - 1;
      } else if (row > 0) {
        targetRow = row - 1;
        targetCol = layout.rows[row - 1].length - 1;
      }
      break;
    case 'right':
      if (col < layout.rows[row].length - 1) {
        targetCol = col + 1;
      } else if (row < layout.rows.length - 1) {
        targetRow = row + 1;
        targetCol = 0;
      }
      break;
  }
  
  if (targetRow === row && targetCol === col) {
    await interaction.reply({ 
      content: lang === 'ar' ? '❌ لا يمكن التحريك في هذا الاتجاه' : '❌ Cannot move in this direction', 
      ephemeral: true 
    });
    return;
  }
  
  // حفظ بيانات النقل المعلق للموافقة/الرفض
  const buttonId = layout.rows[row][col];
  const moveData = {
    buttonId,
    direction,
    fromRow: row,
    fromCol: col,
    toRow: targetRow,
    toCol: targetCol,
    timestamp: Date.now()
  };
  
  db.setPendingButtonMove(interaction.guildId, moveData);
  
  // عرض شاشة التأكيد
  await interaction.update(ButtonManager.createButtonMoveConfirmMenu(userId, lang, moveData));
}

// Handle select menu interactions
export async function handleSelectMenuInteraction(interaction) {
  const userId = interaction.user.id;
  const user = db.getUser(userId);
  const lang = user.language || db.getDefaultLanguage();
  const customId = interaction.customId;

  try {
    // Button layout selection
    if (customId === 'layout_select_btn') {
      const selectedValue = interaction.values[0];
      await interaction.update(ButtonManager.createButtonLayoutMenu(userId, lang, selectedValue));
    }
    
    // Button swap - first selection
    else if (customId === 'swap_select_first') {
      const selectedValue = interaction.values[0];
      // Store first selection and show second menu
      await interaction.update(ButtonManager.createButtonSwapMenu(userId, lang, selectedValue));
    }
    
    // Button swap - second selection (perform swap)
    else if (customId === 'swap_select_second') {
      const secondPos = interaction.values[0];
      // Extract first position from embed description
      const embedDesc = interaction.message.embeds[0]?.description || '';
      const match = embedDesc.match(/(\d+),(\d+)/);
      if (match) {
        const firstPos = `${match[1]},${match[2]}`;
        const [r1, c1] = firstPos.split(',').map(Number);
        const [r2, c2] = secondPos.split(',').map(Number);
        
        const layout = db.getButtonLayout();
        
        // Perform swap
        const temp = layout.rows[r1][c1];
        layout.rows[r1][c1] = layout.rows[r2][c2];
        layout.rows[r2][c2] = temp;
        
        db.updateButtonLayout(layout);
        
        await interaction.update(ButtonManager.createButtonLayoutMenu(userId, lang));
        await interaction.followUp({ 
          content: lang === 'ar' ? '✅ تم تبديل الأزرار بنجاح!' : '✅ Buttons swapped successfully!', 
          ephemeral: true 
        });
      } else {
        await interaction.reply({ content: lang === 'ar' ? '❌ خطأ' : '❌ Error', ephemeral: true });
      }
    }
    
    // Admin user select - add
    else if (customId === 'admin_user_add') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ المالك فقط' : '❌ Owner only', ephemeral: true });
        return;
      }
      const targetUserId = interaction.values[0];
      
      if (db.isAdmin(targetUserId)) {
        await interaction.reply({ 
          content: lang === 'ar' ? '❌ المستخدم مشرف بالفعل' : '❌ User is already an admin', 
          ephemeral: true 
        });
        return;
      }
      
      db.addAdmin(targetUserId);
      await interaction.update(ButtonManager.createPermissionsMenu(userId, lang));
      await interaction.followUp({ 
        content: lang === 'ar' 
          ? `✅ تم إضافة <@${targetUserId}> كمشرف` 
          : `✅ Added <@${targetUserId}> as admin`, 
        ephemeral: true 
      });
    }
    
    // Admin user select - remove
    else if (customId === 'admin_user_remove') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ المالك فقط' : '❌ Owner only', ephemeral: true });
        return;
      }
      const targetUserId = interaction.values[0];
      
      if (!db.isAdmin(targetUserId) || db.isOwner(targetUserId)) {
        await interaction.reply({ 
          content: lang === 'ar' ? '❌ المستخدم ليس مشرفاً أو لا يمكن إزالته' : '❌ User is not an admin or cannot be removed', 
          ephemeral: true 
        });
        return;
      }
      
      db.removeAdmin(targetUserId);
      await interaction.update(ButtonManager.createPermissionsMenu(userId, lang));
      await interaction.followUp({ 
        content: lang === 'ar' 
          ? `✅ تم إزالة <@${targetUserId}> من المشرفين` 
          : `✅ Removed <@${targetUserId}> from admins`, 
        ephemeral: true 
      });
    }
    
    // Log channel select
    else if (customId === 'log_channel_select') {
      if (!db.checkPermission(userId, 'admin')) {
        await interaction.reply({ content: lang === 'ar' ? '❌ صلاحية الأدمن فقط' : '❌ Admin only', ephemeral: true });
        return;
      }
      const channelId = interaction.values[0];
      
      db.setLogChannel(interaction.guildId, channelId);
      db.addAllianceLog('set_log_channel', userId, { channelId });
      
      await interaction.update(ButtonManager.createLogsMenu(lang));
      await interaction.followUp({ 
        content: lang === 'ar' 
          ? `✅ تم تعيين <#${channelId}> كقناة للسجلات` 
          : `✅ Set <#${channelId}> as log channel`, 
        ephemeral: true 
      });
    }

    // ============ معالجات حذف المواعيد المخصصة ============
    else if (customId.startsWith('select_delete_booking_')) {
      const type = customId.replace('select_delete_booking_', '');
      const bookingId = interaction.values[0];
      
      // حذف الموعد المحدد
      db.removeGuildBooking(interaction.guildId, type, bookingId);
      
      await interaction.update(ButtonManager.createSelectDeleteMenu(interaction.guildId, type, lang));
      await interaction.followUp({ 
        content: lang === 'ar' ? '✅ تم حذف الموعد بنجاح!' : '✅ Appointment deleted successfully!',
        ephemeral: true 
      });
    }

    // ============ معالجات تعديل النصوص ============
    else if (customId === 'select_text_to_edit') {
      if (!db.isOwner(userId)) {
        await interaction.reply({ content: lang === 'ar' ? '❌ المالك فقط' : '❌ Owner only', ephemeral: true });
        return;
      }
      const textKey = interaction.values[0];
      
      // عرض modal لتعديل النص
      const textLabels = {
        mainTitle: { ar: 'العنوان الرئيسي', en: 'Main Title' },
        welcomeMessage: { ar: 'رسالة الترحيب', en: 'Welcome Message' },
        allianceTitle: { ar: 'عنوان التحالف', en: 'Alliance Title' },
        membersTitle: { ar: 'عنوان الأعضاء', en: 'Members Title' },
        bookingsTitle: { ar: 'عنوان الحجوزات', en: 'Bookings Title' },
        settingsTitle: { ar: 'عنوان الإعدادات', en: 'Settings Title' },
        helpTitle: { ar: 'عنوان المساعدة', en: 'Help Title' },
        statsTitle: { ar: 'عنوان الإحصائيات', en: 'Stats Title' },
        permissionsTitle: { ar: 'عنوان الصلاحيات', en: 'Permissions Title' },
        remindersTitle: { ar: 'عنوان التذكيرات', en: 'Reminders Title' }
      };
      
      const currentTexts = db.getCustomTexts();
      const currentText = currentTexts[textKey] || db.getDefaultTexts()[textKey] || { ar: '', en: '' };
      const label = textLabels[textKey] ? textLabels[textKey][lang] : textKey;
      
      const modal = new ModalBuilder()
        .setCustomId(`edit_text_modal_${textKey}`)
        .setTitle(lang === 'ar' ? `تعديل: ${label}` : `Edit: ${label}`);

      const arInput = new TextInputBuilder()
        .setCustomId('text_ar')
        .setLabel(lang === 'ar' ? 'النص العربي' : 'Arabic Text')
        .setStyle(TextInputStyle.Short)
        .setValue(currentText.ar || '')
        .setRequired(true);

      const enInput = new TextInputBuilder()
        .setCustomId('text_en')
        .setLabel(lang === 'ar' ? 'النص الإنجليزي' : 'English Text')
        .setStyle(TextInputStyle.Short)
        .setValue(currentText.en || '')
        .setRequired(true);

      modal.addComponents(
        new ActionRowBuilder().addComponents(arInput),
        new ActionRowBuilder().addComponents(enInput)
      );

      await interaction.showModal(modal);
    }
    
  } catch (error) {
    console.error('Error handling select menu:', error);
    await interaction.reply({ 
      content: lang === 'ar' ? '❌ حدث خطأ' : '❌ An error occurred', 
      ephemeral: true 
    });
  }
}
