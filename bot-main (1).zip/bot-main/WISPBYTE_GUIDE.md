# 🚀 دليل نشر البوت على WispByte

دليل شامل لرفع وتشغيل البوت على استضافة WispByte.

---

## 📋 المتطلبات الأساسية

- ✅ حساب على [wispbyte.com](https://wispbyte.com)
- ✅ توكن البوت من Discord Developer Portal
- ✅ معرف المستخدم الخاص بك (OWNER_ID)
- ✅ الملفات المطلوبة جاهزة

---

## 🎯 الخطوات التفصيلية

### 1. إنشاء حساب على WispByte

1. اذهب إلى [wispbyte.com](https://wispbyte.com)
2. اضغط على **Sign Up** أو **Register**
3. أكمل عملية التسجيل
4. تحقق من بريدك الإلكتروني

### 2. إنشاء بوت جديد (New Bot)

1. من لوحة التحكم اضغط **Create New Bot**
2. اختر:
   ```
   Bot Type: Discord Bot
   Bot Language: Node.js
   Node Version: 18.x أو أحدث
   ```

### 3. رفع الملفات

#### **الطريقة الأولى: رفع ملف ZIP**

1. **على جهازك المحلي:**
   ```bash
   # احذف المجلدات غير الضرورية
   rm -rf node_modules
   
   # إنشاء ملف ZIP
   zip -r discord-bot.zip . -x "node_modules/*" ".git/*" ".env"
   ```

2. **على لوحة WispByte:**
   - اذهب إلى **File Manager**
   - اضغط **Upload**
   - ارفع ملف `discord-bot.zip`
   - اضغط **Extract** لفك الضغط

#### **الطريقة الثانية: GitHub Integration**

1. على WispByte اذهب إلى **Settings**
2. اختر **GitHub Integration**
3. ربط حسابك بـ GitHub
4. اختر المستودع: `GameOver305/bot`
5. اضغط **Deploy**

### 4. تثبيت الحزم (Dependencies)

1. افتح **Console** أو **Terminal** في WispByte
2. نفذ هذا الأمر:
   ```bash
   npm install
   ```
3. انتظر حتى تكتمل عملية التثبيت

### 5. إضافة المتغيرات البيئية

#### **في لوحة WispByte:**

1. اذهب إلى **Settings** → **Environment Variables**
2. أضف المتغيرات التالية:

```env
DISCORD_TOKEN=YOUR_BOT_TOKEN_HERE
OWNER_ID=YOUR_USER_ID_HERE
GUILD_ID=YOUR_GUILD_ID_HERE
NODE_ENV=production
```

**كيفية الحصول عليها:**

- **DISCORD_TOKEN:**
  1. اذهب إلى [Discord Developer Portal](https://discord.com/developers/applications)
  2. اختر تطبيقك → Bot → Copy Token

- **OWNER_ID:**
  1. فعّل Developer Mode في Discord (Settings → Advanced → Developer Mode)
  2. انقر بزر الماوس الأيمن على اسمك → Copy ID

- **GUILD_ID:**
  1. انقر بزر الماوس الأيمن على السيرفر → Copy ID

### 6. تحديد أمر التشغيل (Start Command)

في إعدادات WispByte:
```
Start Command: npm start
```

أو:
```
Start Command: node src/index.js
```

### 7. تشغيل البوت

1. اذهب إلى **Console** أو **Control Panel**
2. اضغط **Start Bot** أو زر التشغيل ▶️
3. راقب السجلات (Logs) للتأكد من التشغيل الصحيح

يجب أن ترى رسالة مثل:
```
✅ Bot is ready!
📝 Logged in as: YourBot#1234
```

---

## 🛠️ إعدادات إضافية

### تفعيل إعادة التشغيل التلقائي:

في إعدادات WispByte:
```
Auto Restart: ON
Restart on Crash: ON
```

### تخصيص الذاكرة (إذا متاح):

```
RAM: 512MB (أو أكثر حسب الخطة)
```

---

## 📊 مراقبة البوت

### عرض السجلات (Logs):
```
Dashboard → Logs
```

### التحقق من الحالة:
```
Dashboard → Status
```

يجب أن تكون الحالة: **🟢 Online**

---

## 🔄 تحديث البوت

### الطريقة الأولى: رفع ملفات جديدة
1. احذف الملفات القديمة (عدا `data/` و `node_modules/`)
2. ارفع الملفات الجديدة
3. في Console نفذ: `npm install`
4. أعد تشغيل البوت

### الطريقة الثانية: GitHub Auto Deploy
1. ادفع التعديلات إلى GitHub:
   ```bash
   git add .
   git commit -m "Update bot"
   git push
   ```
2. على WispByte اضغط **Redeploy** أو فعّل Auto Deploy

---

## 🐛 استكشاف الأخطاء الشائعة

### 1. البوت لا يبدأ:
```bash
# تحقق من السجلات في Console
# تأكد من:
- ✅ DISCORD_TOKEN صحيح
- ✅ node_modules مثبتة
- ✅ لا توجد أخطاء في الكود
```

### 2. خطأ "Invalid Token":
```
- تأكد من نسخ التوكن بشكل صحيح
- لا توجد مسافات في بداية أو نهاية التوكن
- جرب إنشاء توكن جديد من Discord
```

### 3. البوت يتوقف بعد فترة:
```
- فعّل Auto Restart
- تحقق من استهلاك الذاكرة
- راجع السجلات للأخطاء
```

### 4. الأوامر لا تظهر:
```
- انتظر حتى ساعة واحدة (لتسجيل الأوامر العالمية)
- أو استخدم GUILD_ID للتسجيل الفوري
- تأكد من صلاحيات البوت في السيرفر
```

---

## 📁 هيكل الملفات على WispByte

بعد الرفع يجب أن يكون:
```
/home/container/
├── src/
│   ├── index.js
│   ├── commands/
│   ├── handlers/
│   └── services/
├── data/
│   ├── bookings.json
│   ├── alliance.json
│   └── users.json
├── package.json
├── package-lock.json
└── node_modules/
```

---

## 💡 نصائح مهمة

### الأمان:
- ✅ **لا تشارك ملف .env أبداً**
- ✅ استخدم Environment Variables في WispByte
- ✅ فعّل Two-Factor Authentication

### الأداء:
- ✅ استخدم أحدث إصدار من Node.js
- ✅ راقب استهلاك الموارد
- ✅ نظف بيانات `data/` بشكل دوري

### النسخ الاحتياطي:
- ✅ احفظ مجلد `data/` باستمرار
- ✅ استخدم GitHub لحفظ الكود
- ✅ سجل المتغيرات البيئية في مكان آمن

---

## 🆘 الحصول على المساعدة

### إذا واجهت مشاكل:

1. **راجع السجلات أولاً:**
   ```
   WispByte Dashboard → Logs → Console Logs
   ```

2. **تحقق من الملفات:**
   ```
   File Manager → تأكد من وجود جميع الملفات
   ```

3. **اتصل بدعم WispByte:**
   - افتح تذكرة (Support Ticket)
   - اشرح المشكلة مع السجلات

4. **مجتمع Discord:**
   - انضم إلى سيرفر WispByte Discord
   - اطلب المساعدة في قناة الدعم

---

## ✅ قائمة المراجعة النهائية

قبل تشغيل البوت، تأكد من:

- [ ] رفع جميع الملفات إلى WispByte
- [ ] تثبيت `node_modules` (npm install)
- [ ] إضافة جميع المتغيرات البيئية
- [ ] تحديد Start Command الصحيح
- [ ] تفعيل Auto Restart
- [ ] دعوة البوت للسيرفر مع الصلاحيات المناسبة
- [ ] التحقق من السجلات بعد التشغيل

---

## 🎉 تم الإعداد بنجاح!

إذا رأيت البوت **أونلاين** في Discord وظهرت الأوامر، فأنت نجحت! 🎊

استخدم `/dang` لبدء استخدام البوت.

---

**ملاحظة:** بعض التفاصيل قد تختلف حسب تحديثات WispByte. راجع وثائقهم الرسمية للمزيد.
