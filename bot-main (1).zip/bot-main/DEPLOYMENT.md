# 🚀 دليل نشر البوت على الاستضافة
# Deployment Guide

هذا الدليل يشرح كيفية نشر البوت على منصات استضافة مختلفة.

---

## 📋 المتطلبات الأساسية

قبل البدء، تأكد من:
- ✅ حساب على منصة الاستضافة
- ✅ توكن البوت من Discord Developer Portal
- ✅ معرف المستخدم الخاص بك (OWNER_ID)

---

## 🌟 WispByte (مخصص للبوتات)

### المميزات:
- ✅ مخصص لاستضافة البوتات
- ✅ لوحة تحكم سهلة
- ✅ دعم فني جيد

### الخطوات السريعة:

1. **التحضير:**
   ```bash
   ./prepare-wispbyte.sh
   ```

2. **الرفع:**
   - اذهب إلى [wispbyte.com](https://wispbyte.com)
   - أنشئ بوت جديد
   - ارفع ملف `discord-bot.zip`

3. **الإعدادات:**
   ```
   Environment Variables:
   - DISCORD_TOKEN=your_token
   - OWNER_ID=your_id
   - GUILD_ID=your_guild_id
   
   Start Command: npm start
   ```

📖 **للدليل الكامل:** راجع [WISPBYTE_GUIDE.md](WISPBYTE_GUIDE.md)

---

## 1️⃣ Railway.app (مجاني - موصى به)

### المميزات:
- ✅ استضافة مجانية 500 ساعة/شهر
- ✅ إعداد سهل جداً
- ✅ دعم GitHub تلقائي

### الخطوات:

1. **إنشاء حساب:**
   - اذهب إلى [railway.app](https://railway.app)
   - سجل دخول باستخدام GitHub

2. **إنشاء مشروع جديد:**
   ```
   - اضغط "New Project"
   - اختر "Deploy from GitHub repo"
   - اختر مستودع البوت
   ```

3. **إضافة المتغيرات البيئية:**
   ```
   Settings → Variables → Add Variable
   
   أضف:
   - DISCORD_TOKEN=YOUR_BOT_TOKEN
   - OWNER_ID=YOUR_USER_ID
   - GUILD_ID=YOUR_GUILD_ID (اختياري)
   ```

4. **النشر:**
   - Railway سيبني وينشر البوت تلقائياً
   - راقب السجلات للتأكد من التشغيل

---

## 2️⃣ Render.com (مجاني)

### المميزات:
- ✅ استضافة مجانية
- ✅ سهل الاستخدام
- ✅ SSL مجاني

### الخطوات:

1. **إنشاء حساب:**
   - اذهب إلى [render.com](https://render.com)
   - سجل دخول

2. **إنشاء Web Service:**
   ```
   - اضغط "New +"
   - اختر "Web Service"
   - ربط مستودع GitHub
   ```

3. **الإعدادات:**
   ```
   Name: discord-bot
   Environment: Node
   Build Command: npm install
   Start Command: npm start
   Instance Type: Free
   ```

4. **المتغيرات البيئية:**
   ```
   Environment → Add Environment Variable:
   - DISCORD_TOKEN
   - OWNER_ID
   - GUILD_ID
   ```

---

## 3️⃣ Replit (مجاني - مع قيود)

### المميزات:
- ✅ سهل جداً للمبتدئين
- ✅ محرر كود مدمج
- ⚠️ يتوقف عند عدم النشاط

### الخطوات:

1. **إنشاء Repl:**
   - اذهب إلى [replit.com](https://replit.com)
   - اضغط "Create Repl"
   - اختر "Import from GitHub"

2. **إضافة المتغيرات:**
   ```
   Tools → Secrets:
   - DISCORD_TOKEN
   - OWNER_ID
   - GUILD_ID
   ```

3. **التشغيل:**
   - اضغط "Run"
   - استخدم خدمة مثل UptimeRobot لإبقاء البوت مستيقظاً

---

## 4️⃣ VPS (Ubuntu/Debian)

### المميزات:
- ✅ تحكم كامل
- ✅ أداء أفضل
- ✅ لا يتوقف

### الخطوات:

1. **الاتصال بالسيرفر:**
   ```bash
   ssh user@your-server-ip
   ```

2. **تثبيت Node.js:**
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt-get install -y nodejs
   sudo npm install -g pm2
   ```

3. **رفع الملفات:**
   ```bash
   # على جهازك المحلي:
   git clone https://github.com/YOUR_USERNAME/bot.git
   cd bot
   
   # أو استخدم scp لرفع الملفات:
   scp -r /path/to/bot user@server-ip:/home/user/
   ```

4. **على السيرفر:**
   ```bash
   cd /home/user/bot
   npm install
   
   # إنشاء ملف .env
   nano .env
   # أضف المتغيرات ثم احفظ بـ Ctrl+X
   
   # تشغيل البوت بـ PM2
   pm2 start ecosystem.config.js
   pm2 save
   pm2 startup
   ```

5. **إدارة البوت:**
   ```bash
   pm2 status              # حالة البوت
   pm2 logs discord-bot    # عرض السجلات
   pm2 restart discord-bot # إعادة التشغيل
   pm2 stop discord-bot    # إيقاف البوت
   ```

---

## 5️⃣ Docker (أي استضافة تدعم Docker)

### الخطوات:

1. **بناء الصورة:**
   ```bash
   docker build -t discord-bot .
   ```

2. **تشغيل الحاوية:**
   ```bash
   docker run -d \
     --name discord-bot \
     --restart unless-stopped \
     -e DISCORD_TOKEN=your_token \
     -e OWNER_ID=your_id \
     -e GUILD_ID=your_guild_id \
     -v $(pwd)/data:/app/data \
     discord-bot
   ```

3. **أو استخدم Docker Compose:**
   ```bash
   docker-compose up -d
   ```

4. **إدارة الحاوية:**
   ```bash
   docker logs discord-bot       # عرض السجلات
   docker restart discord-bot    # إعادة التشغيل
   docker stop discord-bot       # إيقاف
   docker start discord-bot      # تشغيل
   ```

---

## 6️⃣ استضافات مدفوعة أخرى

### DigitalOcean / Linode / Vultr
- اتبع خطوات VPS أعلاه
- سعر يبدأ من $5/شهر

### AWS / Google Cloud / Azure
- أكثر تعقيداً
- مناسب للمشاريع الكبيرة
- لديها طبقات مجانية محدودة

---

## 🔧 نصائح مهمة

### الأمان:
- ✅ **لا تشارك توكن البوت أبداً**
- ✅ استخدم متغيرات بيئية (Environment Variables)
- ✅ لا ترفع ملف `.env` إلى GitHub

### الأداء:
- ✅ استخدم PM2 على VPS للتشغيل المستمر
- ✅ راقب استهلاك الذاكرة
- ✅ فعّل إعادة التشغيل التلقائي

### النسخ الاحتياطي:
- ✅ احفظ نسخة من مجلد `data/`
- ✅ استخدم Git لحفظ التغييرات
- ✅ صدّر إعدادات المتغيرات البيئية

---

## 🆘 استكشاف الأخطاء

### البوت لا يعمل:
```bash
# تحقق من السجلات
pm2 logs discord-bot
# أو
docker logs discord-bot
```

### خطأ في التوكن:
- تأكد من صحة `DISCORD_TOKEN`
- تحقق من صلاحيات البوت في Discord Developer Portal

### البوت يتوقف:
- استخدم PM2 أو Docker restart policies
- تحقق من استهلاك الموارد

---

## 📞 المساعدة

إذا واجهت مشاكل:
1. تحقق من السجلات أولاً
2. راجع ملف TROUBLESHOOTING.md
3. تأكد من المتغيرات البيئية
4. تحقق من اتصال الإنترنت

---

**نصيحة:** ابدأ بـ Railway لأنه الأسهل والأفضل للمبتدئين! 🚀
