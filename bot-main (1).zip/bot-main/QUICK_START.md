# 🎯 دليل البدء السريع - 5 دقائق فقط!

أسرع طريقة لتشغيل البوت في 5 خطوات بسيطة.

---

## ⚡ الطريقة السريعة (محلياً على جهازك)

### 1️⃣ **شغّل سكريبت الإعداد التفاعلي:**

```bash
chmod +x setup.sh
./setup.sh
```

السكريبت سيسألك 3 أسئلة فقط ويعد كل شيء تلقائياً! ✨

---

## 🌐 الطريقة السريعة (على WispByte)

### 1️⃣ **في WispByte Console:**

```bash
git clone https://github.com/GameOver305/bot.git .
npm install
```

### 2️⃣ **أضف المتغيرات:**

في Settings → Environment Variables:
- `DISCORD_TOKEN` = توكن البوت
- `OWNER_ID` = معرفك  
- `GUILD_ID` = معرف السيرفر

### 3️⃣ **Start Command:**

```
npm start
```

### 4️⃣ **اضغط Start ▶️**

---

## 📍 كيف تحصل على المعلومات المطلوبة؟

### 🔑 **DISCORD_TOKEN:**

```
1. https://discord.com/developers/applications
2. New Application (أو اختر موجود)
3. Bot → Reset Token → Copy
```

### 👤 **OWNER_ID:**

```
1. Discord Settings → Advanced → Developer Mode ✅
2. انقر بزر الماوس الأيمن على اسمك
3. Copy User ID
```

### 🏠 **GUILD_ID:**

```
1. انقر بزر الماوس الأيمن على السيرفر
2. Copy Server ID
```

---

## 🎮 **دعوة البوت للسيرفر:**

```
1. https://discord.com/developers/applications
2. OAuth2 → URL Generator
3. Scopes: bot + applications.commands
4. Permissions: Send Messages, Embed Links, Slash Commands
5. Copy URL → افتحه → ادع البوت
```

---

## ✅ **جرب البوت:**

في Discord اكتب:
```
/dang
```

---

## 🆘 **مشاكل؟**

### ❌ **البوت لا يعمل:**

```bash
# تحقق من السجلات
npm start

# أو شاهد الأخطاء
```

### ❌ **خطأ في التوكن:**

- تأكد من نسخ التوكن كاملاً (بدون مسافات)
- جرب إنشاء توكن جديد

### ❌ **الأوامر لا تظهر:**

- انتظر 5-10 دقائق
- أو استخدم GUILD_ID للتسجيل الفوري

---

## 📚 **المزيد من التفاصيل:**

- **[WISPBYTE_GUIDE.md](WISPBYTE_GUIDE.md)** - دليل WispByte الكامل
- **[DEPLOYMENT.md](DEPLOYMENT.md)** - جميع طرق الاستضافة
- **[README.md](README.md)** - وثائق البوت الشاملة

---

**🎉 الآن انت جاهز! استمتع بالبوت!**
